import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

public class SelfOrganizingMap {
	public static void main(String[] args) throws IOException {
		Centeroid[] datasetarray= new SelfOrganizingMap().somMultiplication();
		ArrayList<DataSet> listDataSet= new ReadingInstance().readingData();
		
		for(int i=1;i<listDataSet.size();i++ ) {
			int j=-1;
		double d1=square(datasetarray[0].getNoOfNestedSubQueries(), listDataSet.get(i).getNoOfNestedSubQueries())+
				square(datasetarray[0].getNoOfSelectionPredicate(), listDataSet.get(i).getNoOfSelectionPredicate())+
				square(datasetarray[0].getNoOfEqualitySelectionPredicate(), listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
				square(datasetarray[0].getNoOfNonEqualitySelectionPredicate(), listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
				square(datasetarray[0].getNoOfJoins(), listDataSet.get(i).getNoOfJoins())+
				square(datasetarray[0].getNoOfEquiJoins(), listDataSet.get(i).getNoOfEquiJoins())+
				square(datasetarray[0].getNoOfNonEquiJoins(), listDataSet.get(i).getNoOfNonEquiJoins())+
				square(datasetarray[0].getNoOfSortedColoum(), listDataSet.get(i).getNoOfSortedColoum())+
				square(datasetarray[0].getNoOfAggregationColoum(), listDataSet.get(i).getNoOfAggregationColoum());
		double d2=square(datasetarray[1].getNoOfNestedSubQueries(), listDataSet.get(i).getNoOfNestedSubQueries())+
				square(datasetarray[1].getNoOfSelectionPredicate(), listDataSet.get(i).getNoOfSelectionPredicate())+
				square(datasetarray[1].getNoOfEqualitySelectionPredicate(), listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
				square(datasetarray[1].getNoOfNonEqualitySelectionPredicate(), listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
				square(datasetarray[1].getNoOfJoins(), listDataSet.get(i).getNoOfJoins())+
				square(datasetarray[1].getNoOfEquiJoins(), listDataSet.get(i).getNoOfEquiJoins())+
				square(datasetarray[1].getNoOfNonEquiJoins(), listDataSet.get(i).getNoOfNonEquiJoins())+
				square(datasetarray[1].getNoOfSortedColoum(), listDataSet.get(i).getNoOfSortedColoum())+
				square(datasetarray[1].getNoOfAggregationColoum(), listDataSet.get(i).getNoOfAggregationColoum());
		double d3=square(datasetarray[2].getNoOfNestedSubQueries(), listDataSet.get(i).getNoOfNestedSubQueries())+
				square(datasetarray[2].getNoOfSelectionPredicate(), listDataSet.get(i).getNoOfSelectionPredicate())+
				square(datasetarray[2].getNoOfEqualitySelectionPredicate(), listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
				square(datasetarray[2].getNoOfNonEqualitySelectionPredicate(), listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
				square(datasetarray[2].getNoOfJoins(), listDataSet.get(i).getNoOfJoins())+
				square(datasetarray[2].getNoOfEquiJoins(), listDataSet.get(i).getNoOfEquiJoins())+
				square(datasetarray[2].getNoOfNonEquiJoins(), listDataSet.get(i).getNoOfNonEquiJoins())+
				square(datasetarray[2].getNoOfSortedColoum(), listDataSet.get(i).getNoOfSortedColoum())+
				square(datasetarray[2].getNoOfAggregationColoum(), listDataSet.get(i).getNoOfAggregationColoum());
	
		
		if((d1<d2)&&(d1<d3)) {
			j=0;
			System.out.println(j);
		}
		else if((d2<d1)&&(d2<d3)) {
			j=1;
			System.out.println(j);
		}
		else {
			j=2;
			System.out.println(j);
		}
		}
	}
	public Centeroid[] somMultiplication() throws IOException {
		Centeroid[] datasetarray= new Centeroid[3];
		double alpha =0.5;
		Random random= new Random();
		double NoOfNestedSubQueries1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSelectionPredicate1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEqualitySelectionPredicate1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEqualitySelectionPredicate1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfJoins1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEquiJoins1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEquiJoins1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSortedColoum1=0.1+(0.9-0.1)*random.nextDouble();
		double NoNoOfAggregationColoum1=0.1+(0.9-0.1)*random.nextDouble();
		double SizeOfNode1=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNestedSubQueries2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSelectionPredicate2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEqualitySelectionPredicate2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEqualitySelectionPredicate2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfJoins2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEquiJoins2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEquiJoins2=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSortedColoum2=0.1+(0.9-0.1)*random.nextDouble();
		double NoNoOfAggregationColoum2=0.1+(0.9-0.1)*random.nextDouble();
		///////////////////////////////////////
		double NoOfNestedSubQueries3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSelectionPredicate3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEqualitySelectionPredicate3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEqualitySelectionPredicate3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfJoins3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfEquiJoins3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfNonEquiJoins3=0.1+(0.9-0.1)*random.nextDouble();
		double NoOfSortedColoum3=0.1+(0.9-0.1)*random.nextDouble();
		double NoNoOfAggregationColoum3=0.1+(0.9-0.1)*random.nextDouble();
		//////////////
		double SizeOfNode2=0.1+(0.9-0.1)*random.nextDouble();
		ArrayList<DataSet> listDataSet= new ReadingInstance().readingData();
		for(int i=1;i<listDataSet.size();i++) {
			double a=square(NoOfNestedSubQueries1, listDataSet.get(i).getNoOfNestedSubQueries())+
					square(NoOfSelectionPredicate1, listDataSet.get(i).getNoOfSelectionPredicate())+
					square(NoOfEqualitySelectionPredicate1, listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
					square(NoOfNonEqualitySelectionPredicate1, listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
					square(NoOfJoins1, listDataSet.get(i).getNoOfJoins())+
					square(NoOfEquiJoins1, listDataSet.get(i).getNoOfEquiJoins())+
					square(NoOfNonEquiJoins1, listDataSet.get(i).getNoOfNonEquiJoins())+
					square(NoOfSortedColoum1, listDataSet.get(i).getNoOfSortedColoum())+
					square(NoNoOfAggregationColoum1, listDataSet.get(i).getNoOfAggregationColoum());
					
			double b=square(NoOfNestedSubQueries2, listDataSet.get(i).getNoOfNestedSubQueries())+
					square(NoOfSelectionPredicate2, listDataSet.get(i).getNoOfSelectionPredicate())+
					square(NoOfEqualitySelectionPredicate2, listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
					square(NoOfNonEqualitySelectionPredicate2, listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
					square(NoOfJoins2, listDataSet.get(i).getNoOfJoins())+
					square(NoOfEquiJoins2, listDataSet.get(i).getNoOfEquiJoins())+
					square(NoOfNonEquiJoins2, listDataSet.get(i).getNoOfNonEquiJoins())+
					square(NoOfSortedColoum2, listDataSet.get(i).getNoOfSortedColoum())+
					square(NoNoOfAggregationColoum2, listDataSet.get(i).getNoOfAggregationColoum())
					;
			double c=square(NoOfNestedSubQueries3, listDataSet.get(i).getNoOfNestedSubQueries())+
					square(NoOfSelectionPredicate3, listDataSet.get(i).getNoOfSelectionPredicate())+
					square(NoOfEqualitySelectionPredicate3, listDataSet.get(i).getNoOfEqualitySelectionPredicate())+
					square(NoOfNonEqualitySelectionPredicate3, listDataSet.get(i).getNoOfNonEqualitySelectionPredicate())+
					square(NoOfJoins3, listDataSet.get(i).getNoOfJoins())+
					square(NoOfEquiJoins3, listDataSet.get(i).getNoOfEquiJoins())+
					square(NoOfNonEquiJoins3, listDataSet.get(i).getNoOfNonEquiJoins())+
					square(NoOfSortedColoum3, listDataSet.get(i).getNoOfSortedColoum())+
					square(NoNoOfAggregationColoum3, listDataSet.get(i).getNoOfAggregationColoum())
					;
			if((a<b)&&(a<c)) {
				NoOfNestedSubQueries1=NoOfNestedSubQueries1+alpha*(listDataSet.get(i).getNoOfNestedSubQueries()-NoOfNestedSubQueries1);
				NoOfSelectionPredicate1=NoOfSelectionPredicate1+alpha*(listDataSet.get(i).getNoOfSelectionPredicate()-NoOfSelectionPredicate1);
				NoOfEqualitySelectionPredicate1=NoOfEqualitySelectionPredicate1+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoOfEqualitySelectionPredicate1);
				NoOfNonEqualitySelectionPredicate1=NoOfNonEqualitySelectionPredicate1+alpha*(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()-NoOfNonEqualitySelectionPredicate1);
				NoOfJoins1=NoOfJoins1+alpha*(listDataSet.get(i).getNoOfJoins()-NoOfJoins1);
				NoOfEquiJoins1=NoOfEquiJoins1+alpha*(listDataSet.get(i).getNoOfEquiJoins()-NoOfEquiJoins1);
				NoOfNonEquiJoins1=NoOfNonEquiJoins1+alpha*(listDataSet.get(i).getNoOfNonEquiJoins()-NoOfNonEquiJoins1);
				
				NoOfSortedColoum1=NoOfSortedColoum1+alpha*(listDataSet.get(i).getNoOfSortedColoum()-NoOfSortedColoum1);
				NoNoOfAggregationColoum1=NoNoOfAggregationColoum1+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoNoOfAggregationColoum1);
				//SizeOfNode1= SizeOfNode1+alpha*(listDataSet.get(i).getSizeOfCluster()+)
			}
			else if((b<a)&&(b<c)) {
				NoOfNestedSubQueries2=NoOfNestedSubQueries2+alpha*(listDataSet.get(i).getNoOfNestedSubQueries()-NoOfNestedSubQueries2);
				NoOfSelectionPredicate2=NoOfSelectionPredicate2+alpha*(listDataSet.get(i).getNoOfSelectionPredicate()-NoOfSelectionPredicate2);
				NoOfEqualitySelectionPredicate2=NoOfEqualitySelectionPredicate2+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoOfEqualitySelectionPredicate2);
				NoOfNonEqualitySelectionPredicate2=NoOfNonEqualitySelectionPredicate2+alpha*(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()-NoOfNonEqualitySelectionPredicate2);
				NoOfJoins2=NoOfJoins2+alpha*(listDataSet.get(i).getNoOfJoins()-NoOfJoins2);
				NoOfEquiJoins2=NoOfEquiJoins2+alpha*(listDataSet.get(i).getNoOfEquiJoins()-NoOfEquiJoins2);
				NoOfNonEquiJoins2=NoOfNonEquiJoins2+alpha*(listDataSet.get(i).getNoOfNonEquiJoins()-NoOfNonEquiJoins2);
				
				NoOfSortedColoum2=NoOfSortedColoum2+alpha*(listDataSet.get(i).getNoOfSortedColoum()-NoOfSortedColoum2);
				NoNoOfAggregationColoum2=NoNoOfAggregationColoum2+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoNoOfAggregationColoum2);
						NoOfNestedSubQueries2=NoOfNestedSubQueries2+alpha*(listDataSet.get(i).getNoOfNestedSubQueries()-NoOfNestedSubQueries2);
				NoOfSelectionPredicate2=NoOfSelectionPredicate2+alpha*(listDataSet.get(i).getNoOfSelectionPredicate()-NoOfSelectionPredicate2);
				NoOfEqualitySelectionPredicate2=NoOfEqualitySelectionPredicate2+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoOfEqualitySelectionPredicate2);
				NoOfNonEqualitySelectionPredicate2=NoOfNonEqualitySelectionPredicate2+alpha*(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()-NoOfNonEqualitySelectionPredicate2);
				NoOfJoins2=NoOfJoins2+alpha*(listDataSet.get(i).getNoOfJoins()-NoOfJoins2);
				NoOfEquiJoins2=NoOfEquiJoins2+alpha*(listDataSet.get(i).getNoOfEquiJoins()-NoOfEquiJoins2);
				NoOfNonEquiJoins2=NoOfNonEquiJoins2+alpha*(listDataSet.get(i).getNoOfNonEquiJoins()-NoOfNonEquiJoins2);
				
				NoOfSortedColoum2=NoOfSortedColoum2+alpha*(listDataSet.get(i).getNoOfSortedColoum()-NoOfSortedColoum2);
				NoNoOfAggregationColoum2=NoNoOfAggregationColoum2+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoNoOfAggregationColoum2);
			
			}
			else {
				NoOfNestedSubQueries3=NoOfNestedSubQueries3+alpha*(listDataSet.get(i).getNoOfNestedSubQueries()-NoOfNestedSubQueries3);
				NoOfSelectionPredicate3=NoOfSelectionPredicate3+alpha*(listDataSet.get(i).getNoOfSelectionPredicate()-NoOfSelectionPredicate3);
				NoOfEqualitySelectionPredicate3=NoOfEqualitySelectionPredicate3+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoOfEqualitySelectionPredicate3);
				NoOfNonEqualitySelectionPredicate3=NoOfNonEqualitySelectionPredicate3+alpha*(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()-NoOfNonEqualitySelectionPredicate3);
				NoOfJoins3=NoOfJoins3+alpha*(listDataSet.get(i).getNoOfJoins()-NoOfJoins3);
				NoOfEquiJoins3=NoOfEquiJoins3+alpha*(listDataSet.get(i).getNoOfEquiJoins()-NoOfEquiJoins3);
				NoOfNonEquiJoins3=NoOfNonEquiJoins3+alpha*(listDataSet.get(i).getNoOfNonEquiJoins()-NoOfNonEquiJoins3);
				
				NoOfSortedColoum3=NoOfSortedColoum3+alpha*(listDataSet.get(i).getNoOfSortedColoum()-NoOfSortedColoum3);
				NoNoOfAggregationColoum3=NoNoOfAggregationColoum3+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoNoOfAggregationColoum3);
						NoOfNestedSubQueries3=NoOfNestedSubQueries3+alpha*(listDataSet.get(i).getNoOfNestedSubQueries()-NoOfNestedSubQueries3);
				NoOfSelectionPredicate3=NoOfSelectionPredicate3+alpha*(listDataSet.get(i).getNoOfSelectionPredicate()-NoOfSelectionPredicate3);
				NoOfEqualitySelectionPredicate3=NoOfEqualitySelectionPredicate3+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoOfEqualitySelectionPredicate3);
				NoOfNonEqualitySelectionPredicate3=NoOfNonEqualitySelectionPredicate3+alpha*(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()-NoOfNonEqualitySelectionPredicate3);
				NoOfJoins3=NoOfJoins3+alpha*(listDataSet.get(i).getNoOfJoins()-NoOfJoins3);
				NoOfEquiJoins3=NoOfEquiJoins3+alpha*(listDataSet.get(i).getNoOfEquiJoins()-NoOfEquiJoins3);
				NoOfNonEquiJoins3=NoOfNonEquiJoins3+alpha*(listDataSet.get(i).getNoOfNonEquiJoins()-NoOfNonEquiJoins3);
				
				NoOfSortedColoum3=NoOfSortedColoum3+alpha*(listDataSet.get(i).getNoOfSortedColoum()-NoOfSortedColoum3);
				NoNoOfAggregationColoum3=NoNoOfAggregationColoum3+alpha*(listDataSet.get(i).getNoOfAggregationColoum()-NoNoOfAggregationColoum3);
			
				
			}
					
					
		}
		datasetarray[0]= new Centeroid(NoOfNestedSubQueries1, NoOfSelectionPredicate1, NoOfEqualitySelectionPredicate2, 
				NoOfNonEqualitySelectionPredicate1, NoOfJoins1, NoOfEquiJoins1, NoOfNonEquiJoins1, NoOfSortedColoum1, NoNoOfAggregationColoum1);
		datasetarray[1]= new Centeroid(NoOfNestedSubQueries2, NoOfSelectionPredicate2, NoOfEqualitySelectionPredicate2, 
				NoOfNonEqualitySelectionPredicate2, NoOfJoins2, NoOfEquiJoins2, NoOfNonEquiJoins2, NoOfSortedColoum2, NoNoOfAggregationColoum2);
		datasetarray[2]= new Centeroid(NoOfNestedSubQueries3, NoOfSelectionPredicate3, NoOfEqualitySelectionPredicate3, 
				NoOfNonEqualitySelectionPredicate3, NoOfJoins3, NoOfEquiJoins3, NoOfNonEquiJoins3, NoOfSortedColoum3, NoNoOfAggregationColoum3);
		
		return datasetarray;
	
	}
public ArrayList<DataSet> readingInstance() throws IOException {
	BufferedWriter bufferedWriterTrain= new BufferedWriter(new FileWriter(new File("SOMFile\\CompileMemory4Train.csv")));
	BufferedWriter bufferedWriterTest= new BufferedWriter(new FileWriter(new File("SOMFile\\CompileMemory4Test.csv")));
	bufferedWriterTrain.write("NoOfNestedSubQueries"+","+"NoOfSelectionPredicate"+","+"NoOfEqualitySelectionPredicate"+
			
	","+"NoOfNonEqualitySelectionPredicate"+","+"NoOfJoins"+","+"NoOfEquiJoins"+","+"NoOfNonEquiJoins"+","+
	"NoOfSortedColoum"+","+"NoOfAggregationColoum"+","+"SizeOfNode"+","+"Class"+"\n");
	ArrayList<DataSet> listDataSet= new ReadingInstance().readingData();
	DecimalFormat df = new DecimalFormat("#.00");
	
	for(int i=1;i<848;i++) {
		Random random= new Random();
		
		double var1= 0.1+(0.9-0.1)*random.nextDouble();
		
		double var2=0.1+(0.9-0.1)*random.nextDouble();
		
		double var3=0.1+(0.9-0.1)*random.nextDouble();
		double var4=0.1+(0.9-0.1)*random.nextDouble();
		
		bufferedWriterTrain.write(listDataSet.get(i).getNoOfNestedSubQueries()+","+listDataSet.get(i).getNoOfSelectionPredicate()+","+
				listDataSet.get(i).getNoOfEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfJoins()+","+
							listDataSet.get(i).getNoOfEquiJoins()+","+listDataSet.get(i).getNoOfNonEquiJoins()+","+listDataSet.get(i).getNoOfSortedColoum()+","+listDataSet.get(i).getNoOfAggregationColoum()+","+
							listDataSet.get(i).getCompileMemory()+","+listDataSet.get(i).getClassOfCompileMemory()+","+var1+","+var2+","+var3+","+var4+"\n");

	}
	for(int i=848;i<listDataSet.size();i++) {
		bufferedWriterTest.write(listDataSet.get(i).getNoOfNestedSubQueries()+","+listDataSet.get(i).getNoOfSelectionPredicate()+","+
				listDataSet.get(i).getNoOfEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfJoins()+","+
							listDataSet.get(i).getNoOfEquiJoins()+","+listDataSet.get(i).getNoOfNonEquiJoins()+","+listDataSet.get(i).getNoOfSortedColoum()+","+listDataSet.get(i).getNoOfAggregationColoum()+","+
							listDataSet.get(i).getCompileMemory()+","+listDataSet.get(i).getClassOfCompileMemory()+"\n");

	}
	bufferedWriterTest.flush();
	bufferedWriterTest.close();
	bufferedWriterTrain.flush();
	bufferedWriterTrain.close();
	return listDataSet;
	
	//return listDataSet;
}
public static double square(double num1, double num2) {
	double c;
	c = (num1 - num2);
	return c * c;

}
}
