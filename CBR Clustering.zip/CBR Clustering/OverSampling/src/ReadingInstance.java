import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ReadingInstance {
	public static void main(String[] args) throws IOException {
		//new ReadingInstance().readingData();
		//System.out.println("done");
	}
	
public ArrayList<DataSet> readingData() throws IOException {
	BufferedReader bufferedReader= new FileRead().readingFile("SOMFile\\CachedPlanSize3Train.csv");
	String line = null;
	Scanner scanner = null;
	int index = 0;
	int i = 0;
	ArrayList<DataSet> listDataSet= new ArrayList<DataSet>();
	while ((line = bufferedReader.readLine()) != null) {
		DataSet dataSet = new DataSet();
		scanner = new Scanner(line);
		scanner.useDelimiter(",");
		while (scanner.hasNext()) {
			String data = scanner.next();
			if (index == 0)
			
				try {
					dataSet.setNoOfNestedSubQueries(Integer.parseInt(data));
				} catch (NumberFormatException e) {
					// TODO: handle exception
					dataSet.setNoOfNestedSubQueries(0);
				}
				
			if (index == 1)
				
				try {
					dataSet.setNoOfSelectionPredicate(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfSelectionPredicate(0);
				}
				
			if (index == 2)
				//System.out.println(data);
			
				try {
//					data = data.replaceAll("[^-?0-9]+", " ");
					double d= Double.valueOf(data);
//					System.out.println("Doubly"+ d);
					dataSet.setNoOfEqualitySelectionPredicate(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfEqualitySelectionPredicate(0);
				}
				
			if (index == 3)
				//System.out.println(data);
				try {
					dataSet.setNoOfNonEqualitySelectionPredicate(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfNonEqualitySelectionPredicate(0);
				}
				
			if (index == 4)
				try {
					dataSet.setNoOfJoins(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfJoins(0);
				}
				
			if (index == 5)
				try {
					dataSet.setNoOfEquiJoins(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfEquiJoins(0);
				}
				
			if (index == 6)
				try {
					dataSet.setNoOfNonEquiJoins(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfNonEquiJoins(0);
				}
				
			if (index == 7)
				try {
					dataSet.setNoOfSortedColoum(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfSortedColoum(0);
				}
				
			if (index == 8)
				try {
					dataSet.setNoOfAggregationColoum(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setNoOfAggregationColoum(0);
				}
				
			if(index==9)
				try {
					dataSet.setCompileMemory(Double.parseDouble(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setCompileMemory(0);
				}
			if(index==10)
				try {
					dataSet.setClassOfCompileMemory(Integer.parseInt(data));
				} catch (Exception e) {
					// TODO: handle exception
					dataSet.setClassOfCompileMemory(0);
				}
			double element1=0.0;
			if(index==11)
				try {
					element1= Double.parseDouble(data);
				} catch (Exception e) {
					// TODO: handle exception
					element1=0;
				}
			double element2=0.0;
			if(index==12)
				try {
					element2=Double.parseDouble(data);
				} catch (Exception e) {
					// TODO: handle exception
					element2=0.0;
				}
			double [] element= {element1,element2};
			dataSet.setMemberShipValue(element);
			index++;
		}
		index = 0;
		listDataSet.add(dataSet);
	}
	bufferedReader.close();
	return listDataSet;
}

public void writingFile() throws IOException {
	ArrayList<DataSet> listDataSet= new ReadingInstance().readingData();
	BufferedWriter bufferedWriter= new BufferedWriter( new FileWriter(new File("ExecutionTime.csv")));
	bufferedWriter.write("NoOfNestedSubQueries"+","+"NoOfSelectionPredicate"+","+"NoOfEqualitySelectionPredicate"+
	
","+"NoOfNonEqualitySelectionPredicate"+","+"NoOfJoins"+","+"NoOfEquiJoins"+","+"NoOfNonEquiJoins"+","+
"NoOfSortedColoum"+","+"NoOfAggregationColoum"+","+"ExecutionTime"+","+"Class"+"\n");
	for(int i=1;i<listDataSet.size();i++) {
		bufferedWriter.write(listDataSet.get(i).getNoOfNestedSubQueries()+","+
	listDataSet.get(i).getNoOfSelectionPredicate()+","+listDataSet.get(i).getNoOfEqualitySelectionPredicate()+","+
				listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfJoins()+","+
	listDataSet.get(i).getNoOfEquiJoins()+","+listDataSet.get(i).getNoOfNonEquiJoins()+","+
				listDataSet.get(i).getNoOfSortedColoum()+","+listDataSet.get(i).getNoOfAggregationColoum()+","+listDataSet.get(i).getCompileMemory()+",");
		double compileMemory= listDataSet.get(i).getCompileMemory();
		int classValue=-1;
		if(compileMemory>=100) {
			classValue=1;
		}
			else {
				classValue=0;
			}
		
	bufferedWriter.write(classValue+"\n");
	}
	bufferedWriter.flush();
	bufferedWriter.close();
}
public ArrayList<DataSet> countingClassVariable() throws IOException {
ArrayList<DataSet> listData= new ReadingInstance().readingData();
ArrayList<DataSet> listCount1= new ArrayList<DataSet>();
BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File("CountedFolder\\SizeOfNodeCount1.csv")));
//System.out.println("here");
int count0=0;
int count1=1;
for(int i=1;i<listData.size();i++) {
	if(listData.get(i).getClassOfCompileMemory()==0) {
		count0++;
		//listCount0.add(listData.get(i));
		//					
		
	}
	if(listData.get(i).getClassOfCompileMemory()==1) {
		count1++;
		bufferedWriter.write(listData.get(i).getNoOfNestedSubQueries()+","+
				listData.get(i).getNoOfSelectionPredicate()+","+listData.get(i).getNoOfEqualitySelectionPredicate()+","+
						listData.get(i).getNoOfNonEqualitySelectionPredicate()+","+listData.get(i).getNoOfJoins()+","+
				listData.get(i).getNoOfEquiJoins()+","+listData.get(i).getNoOfNonEquiJoins()+","+listData.get(i).getNoOfSortedColoum()+","+
						listData.get(i).getNoOfAggregationColoum()+","+listData.get(i).getCompileMemory()+","+listData.get(i).getClassOfCompileMemory()+"\n");		

		
	//listCount1.add(listData.get(i));
		

		
	}
	
}
bufferedWriter.flush();
bufferedWriter.close();
System.out.println( "Count 0   "+count0);
System.out.println("Count 1   "+count1);
return listCount1;
}
}
