import java.util.Arrays;

public class Collected {
private double [] arr;

public double [] getArr() {
	return arr;
}

public void setArr(double [] arr) {
	this.arr = arr;
}

@Override
public String toString() {
	return "Collected [arr=" + Arrays.toString(arr) + "]";
}



}
