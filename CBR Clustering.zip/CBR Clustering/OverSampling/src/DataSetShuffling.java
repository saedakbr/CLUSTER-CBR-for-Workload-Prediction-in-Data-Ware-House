import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;


public class DataSetShuffling {
	public ArrayList<DataSet> dataSetShuffle() throws IOException {
		ArrayList<DataSet> listDataSet = new ReadingInstance().readingData();
		ArrayList<DataSet> listDataSet1= new ArrayList<DataSet>();
		for(int i=1;i<listDataSet.size();i++) {
		listDataSet1.add(listDataSet.get(i))	;
		}
		System.out.println(listDataSet1.size());
		return listDataSet1;
	}
public static void main(String[] args) throws IOException {
ArrayList<DataSet> list=	new DataSetShuffling().dataSetShuffle();
Collections.shuffle(list);
BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File("Shuffled\\ExecutionTime.csv")));
BufferedWriter bufferedWriterFCM= new BufferedWriter(new FileWriter(new File("FCM\\ExecutionTime.csv")));
bufferedWriter.write("NoOfNestedSubQueries"+","+"NoOfSelectionPredicate"+","+"NoOfEqualitySelectionPredicate"+
		
","+"NoOfNonEqualitySelectionPredicate"+","+"NoOfJoins"+","+"NoOfEquiJoins"+","+"NoOfNonEquiJoins"+","+
"NoOfSortedColoum"+","+"NoOfAggregationColoum"+","+"SizeOfNode"+","+"Class"+"\n");
for(int i=0;i<list.size();i++) {
	bufferedWriter.write(list.get(i).getNoOfNestedSubQueries()+","+list.get(i).getNoOfSelectionPredicate()+","+
list.get(i).getNoOfEqualitySelectionPredicate()+","+list.get(i).getNoOfNonEqualitySelectionPredicate()+","+list.get(i).getNoOfJoins()+","+
			list.get(i).getNoOfEquiJoins()+","+list.get(i).getNoOfNonEquiJoins()+","+list.get(i).getNoOfSortedColoum()+","+list.get(i).getNoOfAggregationColoum()+","+
			list.get(i).getCompileMemory()+","+list.get(i).getClassOfCompileMemory()+"\n");
}
for(int i=0;i<list.size();i++) {
	bufferedWriterFCM.write(list.get(i).getNoOfNestedSubQueries()+","+list.get(i).getNoOfSelectionPredicate()+","+
list.get(i).getNoOfEqualitySelectionPredicate()+","+list.get(i).getNoOfNonEqualitySelectionPredicate()+","+list.get(i).getNoOfJoins()+","+
			list.get(i).getNoOfEquiJoins()+","+list.get(i).getNoOfNonEquiJoins()+","+list.get(i).getNoOfSortedColoum()+","+list.get(i).getNoOfAggregationColoum()+","+
			list.get(i).getCompileMemory()+","+list.get(i).getClassOfCompileMemory()+"\n");
}
bufferedWriter.flush();
bufferedWriter.close();
bufferedWriterFCM.flush();
bufferedWriterFCM.close();
}
}
