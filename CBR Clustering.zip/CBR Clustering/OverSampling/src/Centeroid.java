import java.util.Arrays;

public class Centeroid {
	private double noOfNestedSubQueries;
	private double noOfSelectionPredicate;
	private double noOfEqualitySelectionPredicate;
	private double noOfNonEqualitySelectionPredicate;
	private double noOfJoins;
	private  double noOfEquiJoins;
	private double noOfNonEquiJoins;
	private double noOfSortedColoum;
	private double noOfAggregationColoum;
	private double lastObject;
	private double classOfCompileMemory;
	private double sizeOfCluster;
	private double [] memberShipValue;
	
	public Centeroid(double noOfNestedSubQueries, double noOfSelectionPredicate, double noOfEqualitySelectionPredicate,
			double noOfNonEqualitySelectionPredicate, double noOfJoins, double noOfEquiJoins, double noOfNonEquiJoins,
			double noOfSortedColoum, double noOfAggregationColoum) {
		super();
		this.noOfNestedSubQueries = noOfNestedSubQueries;
		this.noOfSelectionPredicate = noOfSelectionPredicate;
		this.noOfEqualitySelectionPredicate = noOfEqualitySelectionPredicate;
		this.noOfNonEqualitySelectionPredicate = noOfNonEqualitySelectionPredicate;
		this.noOfJoins = noOfJoins;
		this.noOfEquiJoins = noOfEquiJoins;
		this.noOfNonEquiJoins = noOfNonEquiJoins;
		this.noOfSortedColoum = noOfSortedColoum;
		this.noOfAggregationColoum = noOfAggregationColoum;
	}
	public double getNoOfNestedSubQueries() {
		return noOfNestedSubQueries;
	}
	public void setNoOfNestedSubQueries(double noOfNestedSubQueries) {
		this.noOfNestedSubQueries = noOfNestedSubQueries;
	}
	public double getNoOfSelectionPredicate() {
		return noOfSelectionPredicate;
	}
	public void setNoOfSelectionPredicate(double noOfSelectionPredicate) {
		this.noOfSelectionPredicate = noOfSelectionPredicate;
	}
	public double getNoOfEqualitySelectionPredicate() {
		return noOfEqualitySelectionPredicate;
	}
	public void setNoOfEqualitySelectionPredicate(double noOfEqualitySelectionPredicate) {
		this.noOfEqualitySelectionPredicate = noOfEqualitySelectionPredicate;
	}
	public double getNoOfNonEqualitySelectionPredicate() {
		return noOfNonEqualitySelectionPredicate;
	}
	public void setNoOfNonEqualitySelectionPredicate(double noOfNonEqualitySelectionPredicate) {
		this.noOfNonEqualitySelectionPredicate = noOfNonEqualitySelectionPredicate;
	}
	public double getNoOfJoins() {
		return noOfJoins;
	}
	public void setNoOfJoins(double noOfJoins) {
		this.noOfJoins = noOfJoins;
	}
	public double getNoOfEquiJoins() {
		return noOfEquiJoins;
	}
	public void setNoOfEquiJoins(double noOfEquiJoins) {
		this.noOfEquiJoins = noOfEquiJoins;
	}
	public double getNoOfNonEquiJoins() {
		return noOfNonEquiJoins;
	}
	public void setNoOfNonEquiJoins(double noOfNonEquiJoins) {
		this.noOfNonEquiJoins = noOfNonEquiJoins;
	}
	public double getNoOfSortedColoum() {
		return noOfSortedColoum;
	}
	public void setNoOfSortedColoum(double noOfSortedColoum) {
		this.noOfSortedColoum = noOfSortedColoum;
	}
	public double getNoOfAggregationColoum() {
		return noOfAggregationColoum;
	}
	public void setNoOfAggregationColoum(double noOfAggregationColoum) {
		this.noOfAggregationColoum = noOfAggregationColoum;
	}
	public double getCompileMemory() {
		return lastObject;
	}
	public void setCompileMemory(double compileMemory) {
		this.lastObject = compileMemory;
	}
	public double getClassOfCompileMemory() {
		return classOfCompileMemory;
	}
	public void setClassOfCompileMemory(double classOfCompileMemory) {
		this.classOfCompileMemory = classOfCompileMemory;
	}
	public double getSizeOfCluster() {
		return sizeOfCluster;
	}
	public void setSizeOfCluster(double sizeOfCluster) {
		this.sizeOfCluster = sizeOfCluster;
	}
	public double [] getMemberShipValue() {
		return memberShipValue;
	}
	public void setMemberShipValue(double [] memberShipValue) {
		this.memberShipValue = memberShipValue;
	}
	public Centeroid() {
		
	}
	public Centeroid(double noOfNestedSubQueries, double noOfSelectionPredicate, double noOfEqualitySelectionPredicate,
			double noOfNonEqualitySelectionPredicate, double noOfJoins, double noOfEquiJoins, double noOfNonEquiJoins,
			double noOfSortedColoum, double noOfAggregationColoum, double lastObject, double classOfCompileMemory) {
		
		this.noOfNestedSubQueries = noOfNestedSubQueries;
		this.noOfSelectionPredicate = noOfSelectionPredicate;
		this.noOfEqualitySelectionPredicate = noOfEqualitySelectionPredicate;
		this.noOfNonEqualitySelectionPredicate = noOfNonEqualitySelectionPredicate;
		this.noOfJoins = noOfJoins;
		this.noOfEquiJoins = noOfEquiJoins;
		this.noOfNonEquiJoins = noOfNonEquiJoins;
		this.noOfSortedColoum = noOfSortedColoum;
		this.noOfAggregationColoum = noOfAggregationColoum;
		this.lastObject = lastObject;
		this.classOfCompileMemory = classOfCompileMemory;
	}
	@Override
	public String toString() {
		return "Centeroid [noOfNestedSubQueries=" + noOfNestedSubQueries + ", noOfSelectionPredicate="
				+ noOfSelectionPredicate + ", noOfEqualitySelectionPredicate=" + noOfEqualitySelectionPredicate
				+ ", noOfNonEqualitySelectionPredicate=" + noOfNonEqualitySelectionPredicate + ", noOfJoins="
				+ noOfJoins + ", noOfEquiJoins=" + noOfEquiJoins + ", noOfNonEquiJoins=" + noOfNonEquiJoins
				+ ", noOfSortedColoum=" + noOfSortedColoum + ", noOfAggregationColoum=" + noOfAggregationColoum
				+ ", lastObject=" + lastObject + ", classOfCompileMemory=" + classOfCompileMemory + ", sizeOfCluster="
				+ sizeOfCluster + ", memberShipValue=" + Arrays.toString(memberShipValue) + "]";
	}

}
