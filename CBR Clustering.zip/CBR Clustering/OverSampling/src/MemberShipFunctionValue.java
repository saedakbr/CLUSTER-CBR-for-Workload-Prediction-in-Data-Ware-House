

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class MemberShipFunctionValue {
	BufferedWriter bufferedWriter;
	private long startTime=System.nanoTime();
	public ArrayList<DataSet> memberShipCalculation() throws IOException {
		int a=0;
		bufferedWriter= new BufferedWriter(new FileWriter(new File("s.csv")));
	//	System.out.println("a");
		ArrayList<DataSet> listWithMemberFunction= new ArrayList<DataSet>();
		ArrayList<DataSet> listDataSet= new ReadingInstance().readingData();
		//Scanner scanner = new Scanner(System.in);
		double [] membershipValu;
		//float valueUpdate=(float) 0.0;
		for(int i=1;i<listDataSet.size();i++) {
			DataSet dataSet= new DataSet();
			//System.out.println(i);
			ArrayList<Collected> listCollecteds=new MemberShipFunctionValue().loopBack(new double[2], 0);
			//SSystem.out.println(i);
//			for(Collected c:listCollecteds) {
//				System.out.println(c +"   "+i);
//			}
			//System.out.println(i);
			dataSet.setNoOfNestedSubQueries(listDataSet.get(i).getNoOfNestedSubQueries());
			dataSet.setNoOfSelectionPredicate(listDataSet.get(i).getNoOfSelectionPredicate());
			dataSet.setNoOfEqualitySelectionPredicate(listDataSet.get(i).getNoOfEqualitySelectionPredicate());
			dataSet.setNoOfNonEqualitySelectionPredicate(listDataSet.get(i).getNoOfNonEqualitySelectionPredicate());
			dataSet.setNoOfJoins(listDataSet.get(i).getNoOfJoins());
			dataSet.setNoOfEquiJoins(listDataSet.get(i).getNoOfEquiJoins());
			
			dataSet.setNoOfSortedColoum(listDataSet.get(i).getNoOfSortedColoum());
			dataSet.setNoOfAggregationColoum(listDataSet.get(i).getNoOfAggregationColoum());
			dataSet.setCompileMemory(listDataSet.get(i).getCompileMemory());
			dataSet.setClassOfCompileMemory(listDataSet.get(i).getClassOfCompileMemory());
			//dataSet.setMemberShipValue(listCollecteds.get(i).getArr());
			listWithMemberFunction.add(dataSet);
		}
		bufferedWriter.flush();
		bufferedWriter.close();
	return listWithMemberFunction;
	
	}
	int i=0;
	DecimalFormat df = new DecimalFormat("#.00");
	public ArrayList<Collected> loopBack(double [] membershipValue, double valueUpdate) throws IOException {
		//int k=0;
		ArrayList<Collected> listCollecteds= new ArrayList<Collected>();
		
		for(int j=0;j<membershipValue.length;j++) {
			Random random= new Random();
			
			membershipValue[j]= 0.1+(0.9-0.1)*random.nextDouble();
			String value=df.format(membershipValue[j]);
			double d= Double.parseDouble(value);
			membershipValue[j]=d;
			valueUpdate+=d;
			
			
			
		}
		//System.out.println("val");
		String value=df.format(valueUpdate);
		//double d= Double.parseDouble(value)
      // System.out.println(value);
		if(value.equals("1.00")) {
			
			Collected c= new Collected();
			c.setArr(membershipValue);
			System.out.println(","+membershipValue[0]+ " , "+membershipValue[1]+" ," );
			listCollecteds.add(c);
			//return membershipValue;
		}
		else {
			//System.out.println("Idr bi aya hoon");
			try {
			loopBack(new double[2] , 0);
			}
			catch(StackOverflowError err) {
				long elasped=System.nanoTime()-startTime;
			}
			//return membershipValue;
			//System.out.println(i++);
		//System.out.println("Idr bi aya hoon" + membershipValue.length + valueUpdate);
		}
		return listCollecteds;
		//System.out.println(membershipValue[0]+ "  "+membershipValue[1]+" "+membershipValue[2] );
	}
	public static void main(String[] args) throws IOException {
		new MemberShipFunctionValue().memberShipCalculation();
		
		
	}
	}
