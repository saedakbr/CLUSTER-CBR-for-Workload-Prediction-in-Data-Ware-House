import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class CenteriodCalculation {
	public static void main(String[] args) throws IOException {
		BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File("FuzzyMembershipDefinedfile\\SizeOfNode4.csv")));
		ArrayList<DataSet> listDataSet = new ReadingInstance().readingData();
		ArrayList<Centeroid> listCentriod = new CenteriodCalculation().centeriodCal(listDataSet,
				new ClusterValueReading().ClusterData());
		System.out.println("value h454"+listCentriod.get(0).getNoOfNestedSubQueries());
		
       ArrayList<Collected> listCollectedArray= new CenteriodCalculation().retriveObject(listCentriod,listDataSet);
      // System.out.println(listCollectedArray.size());
	//System.out.println(listCollectedArray);
	for(int i=0;i<20;i++) {
		listCentriod= new CenteriodCalculation().centeriodCal(listDataSet,
				listCollectedArray);
		  listCollectedArray= new CenteriodCalculation().retriveObject(listCentriod,listDataSet);
		  System.out.println("a"+i+"  "+listCentriod);
	}
	//System.out.println(listCollectedArray);
//}
	bufferedWriter.write("NoOfNestedSubQueries"+","+"NoOfSelectionPredicate"+","+"NoOfEqualitySelectionPredicate"+
			
		","+"NoOfNonEqualitySelectionPredicate"+","+"NoOfJoins"+","+"NoOfEquiJoins"+","+"NoOfNonEquiJoins"+","+
		"NoOfSortedColoum"+","+"NoOfAggregationColoum"+","+"CachedPlanSize"+","+"Class"+","+"C1"+","+"C2"+","+"C3"+","+"C4"+"\n");
	for(int i=0;i<listDataSet.size();i++) {
	bufferedWriter.write(listDataSet.get(i).getNoOfNestedSubQueries()+","+listDataSet.get(i).getNoOfSelectionPredicate()+","+
	listDataSet.get(i).getNoOfEqualitySelectionPredicate()+","+listDataSet.get(i).getNoOfNonEqualitySelectionPredicate()+","+
			listDataSet.get(i).getNoOfJoins()+","+listDataSet.get(i).getNoOfEquiJoins()+","+listDataSet.get(i).getNoOfNonEquiJoins()+","+listDataSet.get(i).getNoOfSortedColoum()+","+
	listDataSet.get(i).getNoOfAggregationColoum()+","+listDataSet.get(i).getCompileMemory()+","+listDataSet.get(i).getClassOfCompileMemory()+","+listCollectedArray.get(i).getArr()[0]+","+listCollectedArray.get(i).getArr()[1]+","
	
			+listCollectedArray.get(i).getArr()[2]+","+listCollectedArray.get(i).getArr()[3]+"\n");
//","+listCollectedArray.get(i).getArr()[2]+","+listCollectedArray.get(i).getArr()[3]+	
	}
	bufferedWriter.flush();
	bufferedWriter.close();
	//System.out.println(listCentriod);
	}
public ArrayList<Collected> retriveObject(ArrayList<Centeroid> listCentriod,ArrayList<DataSet> listDataSet) throws IOException{
	HashMap<Integer, ArrayList<Double>>map= new CenteriodCalculation().calculation(listCentriod,listDataSet);
	ArrayList<ArrayList<Double>> test= new ArrayList<ArrayList<Double>>();
	int size=0;
	for(ArrayList<Double> doubleVal: map.values()) {
		size= doubleVal.size();
		test.add(doubleVal);
	}
	ArrayList<Collected> listCollected= new ArrayList<Collected>();
	for(int i=0;i<size;i++) {
		double [] element= new double[4];
		for(int k=0;k<test.size();k++) {
			//System.out.println(test.get(k).get(i)+",      "+k);
			element[k]=test.get(k).get(i);
		}
		Collected collected= new Collected();
		collected.setArr(element);
		listCollected.add(collected);
	}
	return listCollected;
	
}
	public ArrayList<Centeroid> centeriodCal(ArrayList<DataSet> listDataSet, ArrayList<Collected> listClusterValue) {
		DecimalFormat df = new DecimalFormat("#.00");
		ArrayList<Centeroid> listCenteriod = new ArrayList<Centeroid>();
		for (int i = 0; i < 4; i++) {
			double clusterAddtion = 0.0;
			double NoOfNestedSubQueries = 0.0;
			double NoOfSelectionPredicate = 0.0;
			double NoOfEqualitySelectionPredicate = 0.0;
			double NoofNonEqualitySelectionPredicate = 0.0;
			double NoOfJoins = 0.0;
			double NoOfEquiJoins = 0.0;
			double NoOfNonEquiJoin = 0.0;
			double NoOfsortedColoumn = 0.0;
			double NoOfAggregationColoumn = 0.0;
			double object = 0.0;
			
			for (int j = 0; j < listDataSet.size(); j++) {

				NoOfNestedSubQueries += listDataSet.get(j).getNoOfNestedSubQueries()
						* listClusterValue.get(j).getArr()[i];
				//System.out.println(NoOfNestedSubQueries);
				NoOfSelectionPredicate += listDataSet.get(j).getNoOfSelectionPredicate()
						* listClusterValue.get(j).getArr()[i];
				NoOfEqualitySelectionPredicate += listDataSet.get(j).getNoOfEqualitySelectionPredicate()
						* listClusterValue.get(j).getArr()[i];
				NoofNonEqualitySelectionPredicate += listDataSet.get(j).getNoOfNonEqualitySelectionPredicate()
						* listClusterValue.get(j).getArr()[i];
				NoOfJoins += listDataSet.get(j).getNoOfJoins() * listClusterValue.get(j).getArr()[i];
				NoOfEquiJoins += listDataSet.get(j).getNoOfEquiJoins() * listClusterValue.get(j).getArr()[i];
				NoOfNonEquiJoin += listDataSet.get(j).getNoOfNonEquiJoins() * listClusterValue.get(j).getArr()[i];
				NoOfsortedColoumn += listDataSet.get(j).getNoOfSortedColoum() * listClusterValue.get(j).getArr()[i];
				NoOfAggregationColoumn += listDataSet.get(j).getNoOfAggregationColoum()
						* listClusterValue.get(j).getArr()[i];
				//System.out.println(NoOfAggregationColoumn);
				object += listDataSet.get(j).getCompileMemory() * listClusterValue.get(j).getArr()[i];
				//classValue += listDataSet.get(j).getClassOfCompileMemory() * listClusterValue.get(j).getArr()[i];
				clusterAddtion += listClusterValue.get(j).getArr()[i];

			}

			NoOfNestedSubQueries = NoOfNestedSubQueries / clusterAddtion;
//		//	String value1 = df.format(NoOfNestedSubQueries);
//			NoOfNestedSubQueries = Double.parseDouble(value1);

			NoOfSelectionPredicate = NoOfSelectionPredicate / clusterAddtion;
//			String value2 = df.format(NoOfSelectionPredicate);
//			NoOfSelectionPredicate = Double.parseDouble(value2);

			NoOfEqualitySelectionPredicate = NoOfEqualitySelectionPredicate / clusterAddtion;
//			String value3 = df.format(NoOfEqualitySelectionPredicate);
//			NoOfEqualitySelectionPredicate = Double.parseDouble(value3);

			NoofNonEqualitySelectionPredicate = NoofNonEqualitySelectionPredicate / clusterAddtion;
//			String value4 = df.format(NoofNonEqualitySelectionPredicate);
//			NoofNonEqualitySelectionPredicate = Double.parseDouble(value4);

			NoOfJoins = NoOfJoins / clusterAddtion;
//			String value5 = df.format(NoOfJoins);
//			NoOfJoins = Double.parseDouble(value5);

			NoOfEquiJoins = NoOfEquiJoins / clusterAddtion;
//			String value6 = df.format(NoOfEquiJoins);
//			NoOfEquiJoins = Double.parseDouble(value6);

			NoOfNonEquiJoin = NoOfNonEquiJoin / clusterAddtion;
//			String value7 = df.format(NoOfNonEquiJoin);
//			NoOfNonEquiJoin = Double.parseDouble(value7);

			NoOfsortedColoumn = NoOfsortedColoumn / clusterAddtion;
//			String value8 = df.format(NoOfsortedColoumn);
//			NoOfsortedColoumn = Double.parseDouble(value8);
			NoOfAggregationColoumn = NoOfAggregationColoumn / clusterAddtion;
//			String value9 = df.format(NoOfAggregationColoumn);
//			NoOfAggregationColoumn = Double.parseDouble(value9);
			object = object / clusterAddtion;
//			String value10 = df.format(object);
//			object = Double.parseDouble(value10);
			//classValue = classValue / clusterAddtion;
//			String value11 = df.format(classValue);
//			classValue = Double.parseDouble(value11);
			// System.out.println(NoOfNestedSubQueries);
			Centeroid centeroid = new Centeroid();
			centeroid.setNoOfNestedSubQueries(NoOfNestedSubQueries);
			centeroid.setNoOfSelectionPredicate(NoOfSelectionPredicate);
			centeroid.setNoOfEqualitySelectionPredicate(NoOfEqualitySelectionPredicate);
			centeroid.setNoOfNonEqualitySelectionPredicate(NoofNonEqualitySelectionPredicate);
			centeroid.setNoOfJoins(NoOfJoins);
			centeroid.setNoOfEquiJoins(NoOfEquiJoins);
			centeroid.setNoOfNonEquiJoins(NoOfNonEquiJoin);
			centeroid.setNoOfSortedColoum(NoOfsortedColoumn);
			centeroid.setNoOfAggregationColoum(NoOfAggregationColoumn);
			centeroid.setCompileMemory(object);
			//centeroid.setClassOfCompileMemory(classValue);
			listCenteriod.add(centeroid);
			//System.out.println("here");
		}
		return listCenteriod;

	}

	public static double square(double num1, double num2) {
		double c;
		c = (num1 - num2);
		return c * c;

	}
	public ArrayList<ArrayList<SimilarDistance>> distance(ArrayList<Centeroid> listCentriod,ArrayList<DataSet> listDataSet) throws IOException {
		//ArrayList<DataSet> listDataSet = new ReadingInstance().readingData();
//		ArrayList<Centeroid> listCentriod = new CenteriodCalculation().centeriodCal(listDataSet,
//				new ClusterValueReading().ClusterData());
		ArrayList<ArrayList<SimilarDistance>> listSimilarDistance= new ArrayList<ArrayList<SimilarDistance>>();
		for(int i=0;i<listCentriod.size();i++) {
			ArrayList<SimilarDistance> list= new ArrayList<SimilarDistance>();
			for(int j=0;j<listDataSet.size();j++) {
				double distance= square(listCentriod.get(i).getNoOfNestedSubQueries(), listDataSet.get(j).getNoOfNestedSubQueries())+
						square(listCentriod.get(i).getNoOfSelectionPredicate(), listDataSet.get(j).getNoOfSelectionPredicate())+
						square(listCentriod.get(i).getNoOfEqualitySelectionPredicate(), listDataSet.get(j).getNoOfEqualitySelectionPredicate())+
						square(listCentriod.get(i).getNoOfNonEqualitySelectionPredicate(), listDataSet.get(j).getNoOfNonEqualitySelectionPredicate())+
						square(listCentriod.get(i).getNoOfJoins(), listDataSet.get(j).getNoOfJoins())+
						square(listCentriod.get(i).getNoOfEquiJoins(), listDataSet.get(j).getNoOfEquiJoins())+
						square(listCentriod.get(i).getNoOfNonEquiJoins(), listDataSet.get(j).getNoOfNonEquiJoins())+
						square(listCentriod.get(i).getNoOfSortedColoum(), listDataSet.get(j).getNoOfSortedColoum())+
						square(listCentriod.get(i).getNoOfAggregationColoum(), listDataSet.get(j).getNoOfAggregationColoum())+
						square(listCentriod.get(i).getCompileMemory(), listDataSet.get(j).getCompileMemory());
				distance= Math.sqrt(distance);
				SimilarDistance simlarDistance= new SimilarDistance();
				simlarDistance.setDistance(distance);
				//System.out.println(distance+ " cluster "+i);
			list.add(simlarDistance);
			}
			listSimilarDistance.add(list);
		}
		return listSimilarDistance;
	}
public HashMap<Integer, ArrayList<Double>> calculation(ArrayList<Centeroid> listCentriod,ArrayList<DataSet> listDataSet) throws IOException {
	ArrayList<ArrayList<SimilarDistance>> listSimilarDistance= new CenteriodCalculation().distance(listCentriod,listDataSet);
	HashMap<Integer, ArrayList<Double>> map= new HashMap<Integer, ArrayList<Double>>();
	for(int i=0;i<listSimilarDistance.size();i++) {
		double distance=0.0;
		ArrayList<Double> listDistance= new ArrayList<Double>();
		for(int j=0;j<listSimilarDistance.get(i).size();j++) {
			distance=1/listSimilarDistance.get(i).get(j).getDistance();
			//System.out.println(distance+"uper");
			double distance2=0.0;
			for(int k=0;k<listSimilarDistance.size();k++) {
				distance2 += (1/listSimilarDistance.get(k).get(j).getDistance());
			}
			//System.out.println("Distance"+distance2+"  j"+ i);
			distance=distance/distance2;
			//System.out.println(distance);
			listDistance.add(distance);
		}
		map.put(i, listDistance);
	}
	return map;
}
	
}
