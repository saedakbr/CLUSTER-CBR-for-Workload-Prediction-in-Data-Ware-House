import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ClusterValueReading {
	public static void main(String[] args) throws IOException {
	//	ArrayList<Collected> abc=new ClusterValueReading().ClusterData();
		//for(int i=0;i<abc.size();i++) {
//			for(double d:abc.get(i).getArr()) {
//				System.out.println(d +"  "+ i);
//			}
				
		//}
	}
	public ArrayList<Collected> ClusterData() throws IOException {
		BufferedReader bufferedReader= new FileRead().readingFile("MemberShipValue\\SizeOfNode4.csv");
		String line = null;
		Scanner scanner = null;
		int index = 0;
	
		ArrayList<Collected> listDataSet= new ArrayList<Collected>();
		while ((line = bufferedReader.readLine()) != null) {
			Collected dataSet = new Collected();
		double [] elements= new double[4];
			scanner = new Scanner(line);
			scanner.useDelimiter(",");
			while (scanner.hasNext()) {
				String data = scanner.next();
				//System.out.println("here");
				if (index == 0)
				
					try {
						//System.out.println(data);
						//dataSet.setNoOfNestedSubQueries(Integer.parseInt(data));
					} catch (NumberFormatException e) {
						// TODO: handle exception
						//dataSet.setNoOfNestedSubQueries(0);
					}
					
				if (index == 1)
					
					try {
						//System.out.println(data);
						//data = data.replaceAll("[^-?0-9]+", " ");
						double d= Double.valueOf(data);
				//System.out.println(d);
						//dataSet.setNoOfSelectionPredicate(Integer.parseInt(data));
						elements[0]=d;
						//System.out.println(elements[0]);
					} catch (Exception e) {
						// TODO: handle exception
						
					}
if (index == 2)
					
					try {
						//System.out.println(data);
						//data = data.replaceAll("[^-?0-9]+", " ");
						double d= Double.valueOf(data);
						//System.out.println(d);
						//dataSet.setNoOfSelectionPredicate(Integer.parseInt(data));
						elements[1]=d;
						//System.out.println(elements[1]);
					} catch (Exception e) {
						// TODO: handle exception
						
					}
if (index == 3)
	
	try {
		//System.out.println(data);
		//data = data.replaceAll("[^-?0-9]+", " ");
		double d= Double.valueOf(data);
		elements[2]=d;
		//System.out.println(d);
		//dataSet.setNoOfSelectionPredicate(Integer.parseInt(data));
	} catch (Exception e) {
		// TODO: handle exception
		
	}
//////////
if (index == 4)
	
	try {
		//System.out.println(data);
		//data = data.replaceAll("[^-?0-9]+", " ");
		double d= Double.valueOf(data);
		elements[3]=d;
		//System.out.println(d);
		//dataSet.setNoOfSelectionPredicate(Integer.parseInt(data));
	} catch (Exception e) {
		// TODO: handle exception
		
	}			
				index++;
			}
			index = 0;
			dataSet.setArr(elements);
			listDataSet.add(dataSet);
		}
		bufferedReader.close();
		return listDataSet;
	}
}
