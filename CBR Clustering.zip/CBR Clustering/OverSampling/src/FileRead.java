import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileRead {
public BufferedReader readingFile(String file) throws FileNotFoundException {
	BufferedReader bufferedReader= new BufferedReader(new FileReader(new File(file)));
	return bufferedReader;
}
}
