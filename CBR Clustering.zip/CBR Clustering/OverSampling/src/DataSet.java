
public class DataSet {
	private int noOfNestedSubQueries;
	private int noOfSelectionPredicate;
	private int noOfEqualitySelectionPredicate;
	private int noOfNonEqualitySelectionPredicate;
	private int noOfJoins;
	private  int noOfEquiJoins;
	private int noOfNonEquiJoins;
	private int noOfSortedColoum;
	private int noOfAggregationColoum;
	private double lastObject;
	private int classOfCompileMemory;
	
	private int sizeOfCluster;
	
	private double [] memberShipValue;
	
	
	public DataSet(int noOfNestedSubQueries, int noOfSelectionPredicate, int noOfEqualitySelectionPredicate,
			int noOfNonEqualitySelectionPredicate, int noOfJoins, int noOfEquiJoins, int noOfNonEquiJoins,
			int noOfSortedColoum, int noOfAggregationColoum) {
		//super();
		this.noOfNestedSubQueries = noOfNestedSubQueries;
		this.noOfSelectionPredicate = noOfSelectionPredicate;
		this.noOfEqualitySelectionPredicate = noOfEqualitySelectionPredicate;
		this.noOfNonEqualitySelectionPredicate = noOfNonEqualitySelectionPredicate;
		this.noOfJoins = noOfJoins;
		this.noOfEquiJoins = noOfEquiJoins;
		this.noOfNonEquiJoins = noOfNonEquiJoins;
		this.noOfSortedColoum = noOfSortedColoum;
		this.noOfAggregationColoum = noOfAggregationColoum;
	}
	public int getNoOfNestedSubQueries() {
		return noOfNestedSubQueries;
	}
	public void setNoOfNestedSubQueries(int noOfNestedSubQueries) {
		this.noOfNestedSubQueries = noOfNestedSubQueries;
	}
	public int getNoOfSelectionPredicate() {
		return noOfSelectionPredicate;
	}
	public void setNoOfSelectionPredicate(int noOfSelectionPredicate) {
		this.noOfSelectionPredicate = noOfSelectionPredicate;
	}
	public int getNoOfEqualitySelectionPredicate() {
		return noOfEqualitySelectionPredicate;
	}
	public void setNoOfEqualitySelectionPredicate(int noOfEqualitySelectionPredicate) {
		this.noOfEqualitySelectionPredicate = noOfEqualitySelectionPredicate;
	}
	public int getNoOfNonEqualitySelectionPredicate() {
		return noOfNonEqualitySelectionPredicate;
	}
	public void setNoOfNonEqualitySelectionPredicate(int noOfNonEqualitySelectionPredicate) {
		this.noOfNonEqualitySelectionPredicate = noOfNonEqualitySelectionPredicate;
	}
	public int getNoOfJoins() {
		return noOfJoins;
	}
	public void setNoOfJoins(int noOfJoins) {
		this.noOfJoins = noOfJoins;
	}
	public int getNoOfEquiJoins() {
		return noOfEquiJoins;
	}
	public void setNoOfEquiJoins(int noOfEquiJoins) {
		this.noOfEquiJoins = noOfEquiJoins;
	}
	public int getNoOfNonEquiJoins() {
		return noOfNonEquiJoins;
	}
	public void setNoOfNonEquiJoins(int noOfNonEquiJoins) {
		this.noOfNonEquiJoins = noOfNonEquiJoins;
	}
	public int getNoOfSortedColoum() {
		return noOfSortedColoum;
	}
	public void setNoOfSortedColoum(int noOfSortedColoum) {
		this.noOfSortedColoum = noOfSortedColoum;
	}
	public int getNoOfAggregationColoum() {
		return noOfAggregationColoum;
	}
	public void setNoOfAggregationColoum(int noOfAggregationColoum) {
		this.noOfAggregationColoum = noOfAggregationColoum;
	}
	public double getCompileMemory() {
		return lastObject;
	}
	public void setCompileMemory(double compileMemory) {
		this.lastObject = compileMemory;
	}
	public int getClassOfCompileMemory() {
		return classOfCompileMemory;
	}
	public void setClassOfCompileMemory(int classOfCompileMemory) {
		this.classOfCompileMemory = classOfCompileMemory;
	}
	public int getSizeOfCluster() {
		return sizeOfCluster;
	}
	public void setSizeOfCluster(int sizeOfCluster) {
		this.sizeOfCluster = sizeOfCluster;
	}
	public double [] getMemberShipValue() {
		return memberShipValue;
	}
	public void setMemberShipValue(double [] memberShipValue) {
		this.memberShipValue = memberShipValue;
	}
	public DataSet() {

	}

}
