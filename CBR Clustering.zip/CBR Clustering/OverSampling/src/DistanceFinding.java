import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class DistanceFinding {
	public static void main(String[] args) throws IOException {
	new DistanceFinding().numbergenerator();
		}
	
//	public static void main(String[] args) throws IOException {
//		ArrayList<Index> listIndex=new DistanceFinding().distanceFinding(new ReadingInstance().countingClassVariable());
//	System.out.println(listIndex.size());
//	
//	}
public void dataOverSampling() throws IOException {
	BufferedWriter bufferWriter= new BufferedWriter(new FileWriter(new File("SizeOfNodesa.csv")));
	ArrayList<DataSet> listDataSet= new ReadingInstance().countingClassVariable();
	ArrayList<Index> listIndex=new DistanceFinding().distanceFinding(listDataSet);
	//System.out.println("hi"+listIndex.get(0).getJ());
	Random r = new Random();
	for(int i=0;i<listIndex.size();i++) {
		int low=listIndex.get(i).getI();
		//System.out.println(low);
		int high= listIndex.get(i).getJ();
		//System.out.println(high);
		
	for(int j=0; j<=3;j++) {
		int noOfNestedSubQueries=r.nextInt((listDataSet.get(high).getNoOfNestedSubQueries())-(listDataSet.get(low).getNoOfNestedSubQueries()))+
				(listDataSet.get(low).getNoOfNestedSubQueries());
		//System.out.println(noOfNestedSubQueries);
		int noOfSelectionPredicate=r.nextInt((listDataSet.get(high).getNoOfSelectionPredicate())-(listDataSet.get(low).getNoOfSelectionPredicate()))+
				(listDataSet.get(low).getNoOfSelectionPredicate());;
		int noOfEqualitySelectionPredicte=r.nextInt((listDataSet.get(high).getNoOfEqualitySelectionPredicate())-(listDataSet.get(low).getNoOfEqualitySelectionPredicate()))+
				(listDataSet.get(low).getNoOfEqualitySelectionPredicate());
		int noOfNonEqualitySelectionPredicate=r.nextInt((listDataSet.get(high).getNoOfNonEqualitySelectionPredicate())-(listDataSet.get(low).getNoOfNonEqualitySelectionPredicate()))+
				(listDataSet.get(low).getNoOfNonEqualitySelectionPredicate());
		int noOfJoins=r.nextInt((listDataSet.get(high).getNoOfJoins())-(listDataSet.get(low).getNoOfJoins()))+
				(listDataSet.get(low).getNoOfJoins());
		int noOfEquiJoin=r.nextInt((listDataSet.get(high).getNoOfEquiJoins())-(listDataSet.get(low).getNoOfEquiJoins()))+
				(listDataSet.get(low).getNoOfEquiJoins());
		int noOfnonEquiJoin=r.nextInt((listDataSet.get(high).getNoOfNonEquiJoins())-(listDataSet.get(low).getNoOfNonEquiJoins()))+
				(listDataSet.get(low).getNoOfNonEquiJoins());;
		int noOfSortedColoumn=r.nextInt((listDataSet.get(high).getNoOfSortedColoum())-(listDataSet.get(low).getNoOfSortedColoum()))+
				(listDataSet.get(low).getNoOfSortedColoum());
		int noOfAggregatedColoumn=r.nextInt((listDataSet.get(high).getNoOfAggregationColoum())-(listDataSet.get(low).getNoOfAggregationColoum()))+
				(listDataSet.get(low).getNoOfAggregationColoum());;
		double classValue=r.nextInt((listDataSet.get(high).getClassOfCompileMemory())-(listDataSet.get(low).getClassOfCompileMemory()))+
				listDataSet.get(low).getClassOfCompileMemory();
		bufferWriter.write(noOfNestedSubQueries+","+noOfSelectionPredicate+","+noOfEqualitySelectionPredicte+","+ noOfNonEqualitySelectionPredicate+","+
		noOfJoins+","+noOfEquiJoin+","+noOfnonEquiJoin+","+noOfSortedColoumn+","+noOfAggregatedColoumn+","+classValue+","+","+"\n");
	}
	bufferWriter.flush();
	bufferWriter.close();
}


}
	public ArrayList<Index> distanceFinding(ArrayList<DataSet> listData) {
		DataSet dataSet = null;
		
		ArrayList<Index> listIndex= new ArrayList<Index>();
		// double smallestDistance=0;
		for (int i = 0; i < listData.size(); i++) {
			double largestDistance = 0.0;
			int indexj= 0;
			double firstObject = listData.get(i).getCompileMemory();
			for (int j = 1; j < listData.size()-1; j++) {
				double distance = square(firstObject, listData.get(j).getCompileMemory());
				distance=Math.sqrt(distance);
				if (largestDistance <= distance) {
				//	a = listData.get(j).getCompileMemory();
					largestDistance = distance;
					indexj=j;
				}
			}
			Index index=new Index(i, indexj);
			//System.out.println(i+"  "+indexj);
			listIndex.add(index);
			// System.out.println(largestDistance+" "+a);
			//break;
		}
		return listIndex;
	}

	public static double square(double num1, double num2) {
		double c;
		c = (num1 - num2);
		return c * c;

	}
	public static int showRandomInteger(int aStart, int aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		int range =aEnd -  aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		int fraction = (int) (range * aRandom.nextFloat());
		int randomNumber = (int) (fraction + aStart);
		// log("Generated : " + randomNumber);
		return randomNumber;
	}
public void numbergenerator() throws IOException {
	BufferedWriter bufferedWriter= new BufferedWriter(new FileWriter(new File("PopulatedDataSet\\Estimated1.csv")));
	for(int i=0;i<700;i++) {
		bufferedWriter.write(showRandomInteger(1, 4, new Random())+","+
	showRandomInteger(0, 21, new Random())+","+
				showRandomInteger(0, 12, new Random())+","+
	showRandomInteger(0, 12, new Random())+","+
				showRandomInteger(0, 7, new Random())+","+
	showRandomInteger(0, 9, new Random())+","+
				showRandomInteger(0, 8, new Random())+","+
	showRandomInteger(0, 6, new Random())+","+
				showRandomInteger(0, 8, new Random())+","+
	showRandomInteger(7878, 7958, new Random())+","+"0"+"\n");
		
	}
	bufferedWriter.flush();
	bufferedWriter.close();
}
}
