package com.asma.AlgoImplementation;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.asma.Testing.randomLasVegas;
import com.asma.connection.Mysqlconnection;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Algos extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		Mysqlconnection.connetion();
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					Algos frame = new Algos();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
	}

	/**
	 * Create the frame.
	 */
	public Algos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JButton btnMontecarlo = new JButton("MonteCarlo");
		btnMontecarlo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				randomLasVegas randomAlgos = new randomLasVegas();
				try {
					randomAlgos.randomAlgorithm1();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		contentPane.add(btnMontecarlo, BorderLayout.SOUTH);
		
		JButton btnLasvegas = new JButton("Lasvegas");
		btnLasvegas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				randomLasVegas randomAlgos = new randomLasVegas();
				try {
					randomAlgos.randomAlgorithm();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		contentPane.add(btnLasvegas, BorderLayout.NORTH);
	}

}
