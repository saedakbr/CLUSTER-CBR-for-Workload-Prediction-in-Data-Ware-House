package com.asma.AlgoImplementation;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.asma.CBR.CenteriodPointOfCluster;
import com.asma.CBR.InputAndSelectedFeatures;
import com.asma.Simulation.LasVegas;
import com.asma.Testing.randomLasVegas;
import com.asma.connection.Mysqlconnection;
import com.asma.thesis.QueryInputParameters;
import com.mysql.jdbc.Connection;

import weka.classifiers.trees.J48;
import weka.clusterers.ClusterEvaluation;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.core.neighboursearch.kdtrees.KMeansInpiredMethod;

public class AlgoClass {
	private SimpleKMeans kmeans;

	public static void main(String[] args) throws Exception {
		randomLasVegas randomAlgos = new randomLasVegas();
		randomAlgos.randomAlgorithm();
		// note Asma Please comment of them
		// randomAlgos.randomAlgorithm1();

	}

	public ArrayList<QueryInputParameters> algoResult(int number) throws Exception {
		BufferedWriter bufferWriter = new BufferedWriter(new FileWriter("output\\K-means-output.csv"));
		StringBuilder sb = new StringBuilder();
		QueryInputParameters queryInputParameters = null;
		kmeans = new SimpleKMeans();
		DataSource dataSource = new DataSource("test\\estimatedpageschache.csv");
		Instances unlabeled = dataSource.getDataSet();

		kmeans.setPreserveInstancesOrder(true);
		kmeans.setSeed(10);
		kmeans.setPreserveInstancesOrder(true);
		kmeans.setNumClusters(number);
		kmeans.buildClusterer(unlabeled);
		ArrayList<QueryInputParameters> listQueryInputParameter = new ArrayList<>();
		algoResultAlgo(kmeans, unlabeled, queryInputParameters, bufferWriter, listQueryInputParameter);
		System.out.println("num" + listQueryInputParameter.get(0).getNumberOfAggregation());
		return listQueryInputParameter;

	}

	public void algoResultAlgo(SimpleKMeans kmeans, Instances unlabeled, QueryInputParameters queryInputParameter,
			BufferedWriter writer, ArrayList<QueryInputParameters> listQueryInputParameter) throws Exception {
		// ArrayList<QueryInputParameters> listQueryInputParameter = new
		// ArrayList<>();
		int[] assignments = kmeans.getAssignments();
		ClusterEvaluation eval = new ClusterEvaluation();
		eval.setClusterer(kmeans);
		eval.evaluateClusterer(unlabeled);
		Instances labeled = new Instances(unlabeled);
		unlabeled.setClassIndex(unlabeled.numAttributes() - 1);
		J48 j48 = new J48();
		j48.setUnpruned(true);
		String[] split = null;

		for (int j = 0; j < labeled.numInstances(); j++) {
			String a = labeled.instance(j).toString();
			split = a.split(",");
			queryInputParameter = new QueryInputParameters(Integer.valueOf(split[0]), Integer.valueOf(split[1]),
					Integer.valueOf(split[2]), Integer.valueOf(split[3]), Integer.valueOf(split[4]),
					Integer.valueOf(split[5]), Integer.valueOf(split[6]), Integer.valueOf(split[7]),
					Integer.valueOf(split[8]), assignments[j]);
			if (listQueryInputParameter != null)
				listQueryInputParameter.add(queryInputParameter);
			// mapForClusters.put(j, listQueryInputParameter);
		}
		// for(int i=0;i<lis)
		writer.write(labeled.toString());
		writer.newLine();
		writer.flush();

	}

	public HashMap<Integer, ArrayList<QueryInputParameters>> valuesClusterList(int n) throws Exception {
		QueryInputParameters queryInputparameter = null;
		HashMap<Integer, ArrayList<QueryInputParameters>> mapQIP = new HashMap<>();
		ArrayList<QueryInputParameters> listqueryInputparameter = new ArrayList<>();
		ArrayList<QueryInputParameters> listInputAndSelectedFeature = algoResult(n);
		for (int j = 0; j < n; j++) {
			listqueryInputparameter = new ArrayList<>();
			for (int i = 0; i < listInputAndSelectedFeature.size(); i++) {
				if (listInputAndSelectedFeature.get(i).getNumberOfCluster() == j) {
					queryInputparameter = new QueryInputParameters(
							listInputAndSelectedFeature.get(i).getNumberOfNestedSubQueries(),
							listInputAndSelectedFeature.get(i).getNumberOfSelectionPredicates(),
							listInputAndSelectedFeature.get(i).getNumberOfequalitySelectionPredicate(),
							listInputAndSelectedFeature.get(i).getNumberOfnonequalitySelectionPredicate(),
							listInputAndSelectedFeature.get(i).getNumberOfJoins(),
							listInputAndSelectedFeature.get(i).getNumberOfEquiJoinsPredicate(),
							listInputAndSelectedFeature.get(i).getNumberOfNonEquiJoinPredicate(),
							listInputAndSelectedFeature.get(i).getNumberOfSortedColoumn(),
							listInputAndSelectedFeature.get(i).getNumberOfAggregation());
					if (listqueryInputparameter != null)
						listqueryInputparameter.add(queryInputparameter);
				}
			}
			if (mapQIP != null)
				mapQIP.put(j, listqueryInputparameter);
		}
		return mapQIP;

	}

	public ArrayList<CenteriodPointOfCluster> centeriodPointOfCluster(int op) throws Exception {
		CenteriodPointOfCluster centerPointOFCluster = null;
		String[] split = null;
		double b = 0.0;
		ArrayList<CenteriodPointOfCluster> listCenteriodPointOfClusters = new ArrayList<>();
		algoResult(op);
		Instances instances = kmeans.getClusterCentroids();
		String arrInstances = null;
		// System.out.println(instances);
		if (op > instances.size())
			return null;
		if (op == 0 && instances.size() == 0)
			return null;
		for (int i = 0; i < op; i++) {
			arrInstances = instances.get(i).toString();
			split = arrInstances.split(",");
			for (int j = 0; j < split.length - 8; j++) {
				b = Double.valueOf(split[j]);
				// System.out.println(b);
				centerPointOFCluster = new CenteriodPointOfCluster(Double.valueOf(split[0]), Double.valueOf(split[1]),
						Double.valueOf(split[2]), Double.valueOf(split[3]), Double.valueOf(split[4]),
						Double.valueOf(split[5]), Double.valueOf(split[6]), Double.valueOf(split[7]),
						Double.valueOf(split[8]));
			}
			if (listCenteriodPointOfClusters != null) {
				listCenteriodPointOfClusters.add(centerPointOFCluster);
			}

		}
		return listCenteriodPointOfClusters;

	}

	public ArrayList<QueryInputParameters> minimumCenteriodPoint(int numberOfNestedSubQueries,
			int numberOfSelectionPredicates, int numberOfequalitySelectionPredicate,
			int numberOfnonequalitySelectionPredicate, int numberOfJoins, int numberOfEquiJoinsPredicate,
			int numberOfNonEquiJoinPredicate, int numberOfSortedColoumn, int numberOfAggregation, int n)
			throws Exception {
		double number = 0.0;
		int valuePosition = 0;
		ArrayList<Double> listOfEquiDistanceofCenteriodPoints = new ArrayList<>();

		double minnumber = 1400.0;
		ArrayList<CenteriodPointOfCluster> listofCPC = centeriodPointOfCluster(n);
		if (listofCPC != null)
			for (int i = 0; i < listofCPC.size(); i++) {

				number = square(numberOfNestedSubQueries, listofCPC.get(i).getNumberOfNestedSubQueries())
						+ square(numberOfSelectionPredicates, listofCPC.get(i).getNumberOfSelectionPredicates())
						+ square(numberOfequalitySelectionPredicate,
								listofCPC.get(i).getNumberOfequalitySelectionPredicate())
						+ square(numberOfnonequalitySelectionPredicate,
								listofCPC.get(i).getNumberOfnonequalitySelectionPredicate())
						+ square(numberOfJoins, listofCPC.get(i).getNumberOfJoins())
						+ square(numberOfEquiJoinsPredicate, listofCPC.get(i).getNumberOfEquiJoinsPredicate())
						+ square(numberOfNonEquiJoinPredicate, listofCPC.get(i).getNumberOfNonEquiJoinPredicate())
						+ square(numberOfSortedColoumn, listofCPC.get(i).getNumberOfSortedColoumn())
						+ square(numberOfAggregation, listofCPC.get(i).getNumberOfAggregation());
				// number = Double.valueOf(df.format(number));
				// System.out.println("number without sqrt" + number);
				number = Math.sqrt(number);
				if (number < minnumber) {
					minnumber = number;
					valuePosition = i;
					//System.out.println(valuePosition + " minimum number " + minnumber);
				}
			}
		//System.out.println(valuePosition + " minimum number ");
		// try {
		// if (listOfEquiDistanceofCenteriodPoints != null) {
		// double smallestNumber = listOfEquiDistanceofCenteriodPoints.get(0);
		// for (int i = 0; i < listOfEquiDistanceofCenteriodPoints.size(); i++)
		// {
		// // System.out.println(cal.get(i));
		// if (smallestNumber > listOfEquiDistanceofCenteriodPoints.get(i)) {
		// smallestNumber = listOfEquiDistanceofCenteriodPoints.get(i);
		// valuePosition = i;
		// }
		// }
		// }
		// } catch (ArrayIndexOutOfBoundsException e) {
		// // TODO: handle exception
		// }

		HashMap<Integer, ArrayList<QueryInputParameters>> mapQIP = valuesClusterList(n);
		ArrayList<QueryInputParameters> sizeANDinputandSelectedFeatures = null;
		for (Map.Entry<Integer, ArrayList<QueryInputParameters>> traversing : mapQIP.entrySet()) {
			int key = traversing.getKey();
			if (key == valuePosition) {
				sizeANDinputandSelectedFeatures = traversing.getValue();
			}
		}
		return sizeANDinputandSelectedFeatures;

	}

	public static double square(int num1, double num2) {
		double c;
		c = (num1 - num2);
		return c * c;

	}

	public double calculateMinimumNumber(int a, int b, int c, int d, int e, int f, int g, int h, int l, int n)
			throws Exception {
		double minimumNumber = 0.0;
		double minnumber = 1400.0;
		double minValue = 0.0;
		ArrayList<Double> doubleMinimumNumber = new ArrayList<>();
		ArrayList<QueryInputParameters> listQIP = minimumCenteriodPoint(a, b, c, d, e, f, g, h, l, n);
		for (int i = 0; i < listQIP.size(); i++) {
			minimumNumber = square(a, listQIP.get(i).getNumberOfNestedSubQueries())
					+ square(b, listQIP.get(i).getNumberOfSelectionPredicates())
					+ square(c, listQIP.get(i).getNumberOfequalitySelectionPredicate())
					+ square(d, listQIP.get(i).getNumberOfnonequalitySelectionPredicate())
					+ square(e, listQIP.get(i).getNumberOfJoins())
					+ square(f, listQIP.get(i).getNumberOfEquiJoinsPredicate())
					+ square(g, listQIP.get(i).getNumberOfNonEquiJoinPredicate())
					+ square(h, listQIP.get(i).getNumberOfSortedColoumn())
					+ square(l, listQIP.get(i).getNumberOfAggregation());
			minimumNumber = Math.sqrt(minimumNumber);
			if (minimumNumber < minnumber) {
				minnumber = minimumNumber;
				minValue = minnumber;
			}
		}

		minValue = 1 / minValue;
		minValue = Math.round(minValue * 100);
		//System.out.println("number is" + minValue);
		return minValue;
	}

	public static int showRandomInteger(int aStart, int aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		long range = (long) aEnd - (long) aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		long fraction = (long) (range * aRandom.nextDouble());
		int randomNumber = (int) (fraction + aStart);
		//System.out.println("Generated : " + randomNumber);
		return randomNumber;
	}

	public static ArrayList<QueryInputParameters> readinput() throws SQLException {
		Connection conn;
		ArrayList<QueryInputParameters> arrayListQIP = new ArrayList<>();
		String table_selection = "select* from inputparameter";
		conn = (Connection) Mysqlconnection.connetion();
		ResultSet resultset;
		java.sql.Statement statement;
		statement = conn.createStatement();
		resultset = statement.executeQuery(table_selection);
		while (resultset.next()) {
			QueryInputParameters QIPobject = new QueryInputParameters(resultset.getInt("noofnestedsubqueries"),
					resultset.getInt("noofselectionpredictes"), resultset.getInt("noofequalityselectionpredicate"),
					resultset.getInt("noofnonequalityselectionpredicate"), resultset.getInt("noofjoins"),
					resultset.getInt("noofequijoinpredicate"), resultset.getInt("noofnonequijoinpredicate"),
					resultset.getInt("noofsortedcoloumn"), resultset.getInt("noofaggregation"));
			// System.out.println(QIPobject);
			arrayListQIP.add(QIPobject);

		}
		conn.close();
		return arrayListQIP;
	}

}
