package com.asma.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class sqlconnection {
	static Connection conn = null;
	static String dbURL = "jdbc:sqlserver://localhost\\sqlexpress";
	static String user = "Adeel";
	static String pass = "adeel123";

	public static Connection connection() throws SQLException {
		conn = DriverManager.getConnection(dbURL, user, pass);
		return conn;
	}
}
