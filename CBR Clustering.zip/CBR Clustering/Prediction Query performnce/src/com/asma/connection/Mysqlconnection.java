package com.asma.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Mysqlconnection {
	static Connection cnn;
	public static Connection connetion() throws SQLException {
		// try {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			cnn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/asmathesis", "root", "password");
			System.out.println("connected");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("asdeel");
		return cnn;

	}


}
