package com.asma.Testing;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.asma.Simulation.MonteCarlo;
import com.asma.operationCBR.PredictorQueryPerformanceMetric;
import com.asma.thesis.QueryInputParameters;

public class MonteCarloSimulation implements MonteCarlo {
	double currentAccuracy = 0.0;
	private Scanner reader;
	private int predicatedAccuracy = 0;
	private Random rand;
	int size;
	private PredictorQueryPerformanceMetric pred = new PredictorQueryPerformanceMetric();

	@Override
	public int randomAlgorithm() throws Exception {
		rand = new Random();
		int numberOfCluster = 0;
		size = pred.Opertion(1).size();
		reader = new Scanner(System.in);
		System.out.println("Enter Precision Accuracy");
		predicatedAccuracy = reader.nextInt();
		currentAccuracy = 0;
		double db = 0.0;
		ArrayList<QueryInputParameters> inputdata = randomLasVegas.readinput();
		for (int j = 0; j < 1000; j++) {
			int k = showRandomInteger(log(size, 2), size / 2, rand);
			int acuracyK = 0;
			for (int i = 989; i < inputdata.size(); i++) {
				PredictorQueryPerformanceMetric.Opertion(numberOfCluster);
				PredictorQueryPerformanceMetric.finalCalculation(inputdata.get(i).getNumberOfNestedSubQueries(),
						inputdata.get(i).getNumberOfSelectionPredicates(),
						inputdata.get(i).getNumberOfequalitySelectionPredicate(),
						inputdata.get(i).getNumberOfnonequalitySelectionPredicate(),
						inputdata.get(i).getNumberOfJoins(), inputdata.get(i).getNumberOfEquiJoinsPredicate(),
						inputdata.get(i).getNumberOfNonEquiJoinPredicate(), inputdata.get(i).getNumberOfSortedColoumn(),
						inputdata.get(i).getNumberOfAggregation(), numberOfCluster);
				if (db >= 80.0 || db == 0.0) {
					acuracyK = acuracyK + 1;

				}

			}
			if (acuracyK > currentAccuracy) {

				currentAccuracy = acuracyK;
				System.out.println("Here achived ");
				System.out.println("number of cluster" + numberOfCluster);
				break;
			}

		}
		// TODO Auto-generated method stub
		return 0;
	}

	public static int showRandomInteger(int aStart, int aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		// get the range, casting to long to avoid overflow problems
		long range = (long) aEnd - (long) aStart + 1;
		// compute a fraction of the range, 0 <= frac < range
		long fraction = (long) (range * aRandom.nextDouble());
		int randomNumber = (int) (fraction + aStart);
		// log("Generated : " + randomNumber);
		return randomNumber;
	}

	static int log(int x, int base) {
		return (int) (Math.log(x) / Math.log(base));
	}

	@Override
	public int randomAlgorithm1() throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

}
