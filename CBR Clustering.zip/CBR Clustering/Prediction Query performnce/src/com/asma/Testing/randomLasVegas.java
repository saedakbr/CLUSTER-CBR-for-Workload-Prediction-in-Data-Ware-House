package com.asma.Testing;

import java.io.File;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.DefaultListModel;

import com.asma.AlgoImplementation.AlgoClass;
import com.asma.CBR.InputAndSelectedFeatures;
import com.asma.CBR.MinimumNumberCalculation;
import com.asma.Simulation.LasVegas;
import com.asma.Simulation.MonteCarlo;
import com.asma.connection.Mysqlconnection;
import com.asma.operationCBR.PredictorQueryPerformanceMetric;
import com.asma.thesis.QueryInputParameters;
import com.mysql.jdbc.Connection;

public class randomLasVegas implements LasVegas ,MonteCarlo {
	double currentAccuracy = 0.0;
	private Scanner reader;
	private int predicatedAccuracy = 0;
	private Random rand;
	static int size;
	private static PredictorQueryPerformanceMetric pred = new PredictorQueryPerformanceMetric();

	@Override
	public int randomAlgorithm() throws Exception {
		int currentAccuracy = 0;
		FileWriter fileWriter = new FileWriter(new File("Algo\\lasvegas.csv"));
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Thershold Value");
		int thresholdValue = scanner.nextInt();
		fileWriter.write("ThresholdValue" + "," + thresholdValue + "\n");
		fileWriter.write("Number of Cluster" + "," + "Accurary" + "\n");
		AlgoClass algoClass = new AlgoClass();
		ArrayList<QueryInputParameters> listQIP = algoClass.readinput();
		rand = new Random();
		while (currentAccuracy < thresholdValue) {
			int k = showRandomInteger(83, 396, rand);
			int accuracyK = 0;
			for (int i = 793; i < listQIP.size(); i++) {
				double minValue = algoClass.calculateMinimumNumber(listQIP.get(i).getNumberOfNestedSubQueries(),
						listQIP.get(i).getNumberOfSelectionPredicates(),
						listQIP.get(i).getNumberOfequalitySelectionPredicate(),
						listQIP.get(i).getNumberOfnonequalitySelectionPredicate(), listQIP.get(i).getNumberOfJoins(),
						listQIP.get(i).getNumberOfEquiJoinsPredicate(),
						listQIP.get(i).getNumberOfNonEquiJoinPredicate(), listQIP.get(i).getNumberOfSortedColoumn(),
						listQIP.get(i).getNumberOfAggregation(), k);
				if (minValue == 0.0 || minValue >= 80) {
					accuracyK = accuracyK + 1;
				}
				fileWriter.write(k + "," + accuracyK + "\n");

			}
			if (accuracyK > currentAccuracy) {
				currentAccuracy = accuracyK;
				fileWriter.write("Optimal Cluster"+","+k);
			}
		}
		fileWriter.close();
		return predicatedAccuracy;

	}

	public static int showRandomInteger(int aStart, int aEnd, Random aRandom) {
		if (aStart > aEnd) {
			throw new IllegalArgumentException("Start cannot exceed End.");
		}
		System.out.println("start" + aStart + "End" + aEnd);
		// aRandom.setSeed(aStart);
		// System.out.println("mara random number"+aRandom.nextInt(aEnd));
		return aStart + aRandom.nextInt(aEnd - aStart) - 1;
	}

	public static void op() throws Exception {
		for (int i = 0; i < 10; i++) {
			Random rand = new Random();
			size = pred.Opertion(1).size();
			// System.out.println("random number"+showRandomInteger(log(size,
			// 2), size / 2, rand));
		}
	}

	public static ArrayList<QueryInputParameters> readinput() throws SQLException {
		Connection conn;
		ArrayList<QueryInputParameters> arrayListQIP = new ArrayList<>();
		String table_selection = "select* from inputparameter";
		conn = (Connection) Mysqlconnection.connetion();
		ResultSet resultset;
		java.sql.Statement statement;
		statement = conn.createStatement();
		resultset = statement.executeQuery(table_selection);
		while (resultset.next()) {
			QueryInputParameters QIPobject = new QueryInputParameters(resultset.getInt("noofnestedsubqueries"),
					resultset.getInt("noofselectionpredictes"), resultset.getInt("noofequalityselectionpredicate"),
					resultset.getInt("noofnonequalityselectionpredicate"), resultset.getInt("noofjoins"),
					resultset.getInt("noofequijoinpredicate"), resultset.getInt("noofnonequijoinpredicate"),
					resultset.getInt("noofsortedcoloumn"), resultset.getInt("noofaggregation"));
			// System.out.println(QIPobject);
			arrayListQIP.add(QIPobject);

		}
		conn.close();
		return arrayListQIP;
	}

	static int log(int x, int base) {
		return (int) (Math.log(x) / Math.log(base));
	}

	@Override
	public int randomAlgorithm1() throws Exception {
		int currentAccuracy = 0;
		FileWriter fileWriter = new FileWriter(new File("Algo\\montecarlo.csv"));
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter number of iteration");
		int numberOfIteration = scanner.nextInt();
		fileWriter.write("ThresholdValue" + "," + numberOfIteration + "\n");
		fileWriter.write("Number of Cluster" + "," + "Accurary" + "\n");
		AlgoClass algoClass = new AlgoClass();
		ArrayList<QueryInputParameters> listQIP = algoClass.readinput();
		rand = new Random();
		for(int j=0;j<numberOfIteration;j++){
			int k = showRandomInteger(83, 396, rand);
			int accuracyK = 0;

			for (int i = 793; i < listQIP.size(); i++) {
				double minValue = algoClass.calculateMinimumNumber(listQIP.get(i).getNumberOfNestedSubQueries(),
						listQIP.get(i).getNumberOfSelectionPredicates(),
						listQIP.get(i).getNumberOfequalitySelectionPredicate(),
						listQIP.get(i).getNumberOfnonequalitySelectionPredicate(), listQIP.get(i).getNumberOfJoins(),
						listQIP.get(i).getNumberOfEquiJoinsPredicate(),
						listQIP.get(i).getNumberOfNonEquiJoinPredicate(), listQIP.get(i).getNumberOfSortedColoumn(),
						listQIP.get(i).getNumberOfAggregation(), k);
				if (minValue == 0.0 || minValue >= 80) {
					accuracyK = accuracyK + 1;
				}
				
			}
			fileWriter.write(k + "," + accuracyK + "\n");
			if (accuracyK > currentAccuracy) {
				currentAccuracy = accuracyK;
				fileWriter.write("Optimal Cluster"+","+k+"\n");
			}
		}
		System.out.println("written");
		fileWriter.close();
		return 0;
	}
}
