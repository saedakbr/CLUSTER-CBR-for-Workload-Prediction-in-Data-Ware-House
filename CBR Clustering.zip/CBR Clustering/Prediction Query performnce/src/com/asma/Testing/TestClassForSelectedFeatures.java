package com.asma.Testing;

import com.asma.CBR.SelectedFeature;

public class TestClassForSelectedFeatures {
	private SelectedFeature SF=null;
	private double predicatedPercentage=0.0;
	private double ecludianDistance=0.0;
	
	public TestClassForSelectedFeatures(SelectedFeature sF, double predicatedPercentage, double ecludianDistance) {
		SF = sF;
		this.predicatedPercentage = predicatedPercentage;
		this.ecludianDistance = ecludianDistance;
	}
	public SelectedFeature getSF() {
		return SF;
	}
	public void setSF(SelectedFeature sF) {
		SF = sF;
	}
	public double getPredicatedPercentage() {
		return predicatedPercentage;
	}
	public void setPredicatedPercentage(double predicatedPercentage) {
		this.predicatedPercentage = predicatedPercentage;
	}
	public double getEcludianDistance() {
		return ecludianDistance;
	}
	public void setEcludianDistance(double ecludianDistance) {
		this.ecludianDistance = ecludianDistance;
	}
	

}
