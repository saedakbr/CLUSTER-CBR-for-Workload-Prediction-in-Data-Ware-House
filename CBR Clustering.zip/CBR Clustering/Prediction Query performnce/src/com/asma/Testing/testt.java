//package com.asma.Testing;
//
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//import com.asma.CBR.InputAndSelectedFeatures;
//
//public class testt {
//	public static void sizeOfNode() throws Exception {
//		int truePositive = 0;
//		int trueNegative = 0;
//		int falsePositive = 0;
//		int falseNegative = 0;
//		int actualzeroNumber = 0;
//		int actual1Number = 0;
//		int predicatedzeroNumber = 0;
//		int predicated1Number = 0;
//		int total = 0;
//		int n = 0;
//		BufferedWriter bufferwriter = null;
//		StringBuilder sb1 = new StringBuilder();
//		reader = new Scanner(System.in);
//		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\result.csv")));
//		System.out.println("Enter number of Clusters");
//		String Class = null;
//		n = reader.nextInt();
//		int predication = 0;
//		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
//		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
//				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
//				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
//				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
//				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
//				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
//				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
//				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
//				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
//				+ "\n");
//		// System.out.println(inputdata.size());
//
//		for (int i = 793; i < inputdata.size(); i++) {
//			listInputAndSelectedFeature = Opertion(n);
//			TestClassForSelectedFeatures TCFSF = finalCalculation(
//					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
//					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
//			// System.out.println("Eculidain
//			// Distance"+TCFSF.getEcludianDistance());
//			if (inputdata.get(i).getSelctedfeature().getSizeOfNodes() <= 15) {
//				Class = "0";
//				actualzeroNumber = actualzeroNumber + 1;
//
//			} else {
//				Class = "1";
//				actual1Number = actual1Number + 1;
//			}
//			if (TCFSF.getSF().getClasses().equals("0"))
//				predicatedzeroNumber = predicatedzeroNumber + 1;
//			if (TCFSF.getSF().getClasses().equals("1"))
//				predicated1Number = predicated1Number + 1;
//
//			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
//				predication = 1;
//			} else {
//				predication = 0;
//			}
//			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
//				truePositive = truePositive + 1;
//			}
//			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
//				falsePositive = falsePositive + 1;
//			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
//				falseNegative = falseNegative + 1;
//			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
//				trueNegative = trueNegative + 1;
//			// System.out.println("truePositive "+truePositive);
//
//			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
//					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
//			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
//					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
//					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
//					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
//					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
//					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
//					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
//			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
//					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
//					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
//					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
//			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
//			sb1.append(predication + ",");
//			sb1.append("\n");
//
//			// System.out.println(sb1.toString());
//
//		}
//		System.out.println("predicted Long number" + predicated1Number);
//		bufferwriter.write(sb1.toString() + "\n" + "\n");
//		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
//		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
//		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
//		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
//		total = (truePositive + trueNegative + falsePositive + falseNegative);
//		double accuracy = (truePositive + trueNegative);
//		accuracy = (accuracy / total);
//		double misclassificationRate = (falsePositive + falseNegative);
//		misclassificationRate = (misclassificationRate / total);
//		double actLongnumber = actual1Number;
//		double actShortnumber = actualzeroNumber;
//		double v = truePositive + falseNegative;
//		double truePositiveRate = (truePositive / v);
//		double fpr = (falsePositive + trueNegative);
//		double falsePositiveRate = (falsePositive / fpr);
//		double specificity = (trueNegative / actShortnumber);
//		double val = (truePositive + falsePositive);
//		System.out.println("Result" + val);
//		precision = truePositive / val;
//		double FMeasure = 2 * (precision * truePositiveRate);
//		FMeasure = FMeasure / (precision + truePositiveRate);
//		System.out.println(truePositive + "result " + precision);
//		double prevalence = (actLongnumber / total);
//		bufferwriter.write("\n");
//		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
//		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
//		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
//		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
//		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
//		bufferwriter.write("," + "precision " + "," + precision + "\n");
//		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
//		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");
//
//		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
//		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
//		// "+precision+" "+prevalence);
//
//		bufferwriter.close();
//		// bufferwriter.flush();
//
//	}
//
//
//}
