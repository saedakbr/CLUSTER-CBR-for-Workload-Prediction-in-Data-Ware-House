package com.asma.Testing;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.asma.CBR.InputAndSelectedFeatures;
import com.asma.CBR.SelectedFeature;
import com.asma.connection.Mysqlconnection;
import com.asma.connection.sqlconnection;
import com.asma.thesis.QueryInputParameters;
import com.mysql.jdbc.Connection;

public class Testfile {
	public static ArrayList<InputAndSelectedFeatures> resultFile() throws SQLException {
		Connection conn = (Connection) Mysqlconnection.connetion();
		ArrayList<InputAndSelectedFeatures> inputandSelected = new ArrayList<>();
		String table_selection = "SELECT inputparameter.noofnestedsubqueries,inputparameter.noofselectionpredictes,inputparameter.noofequalityselectionpredicate,inputparameter.noofnonequalityselectionpredicate,inputparameter.noofjoins, inputparameter.noofequijoinpredicate,inputparameter.noofnonequijoinpredicate,inputparameter.noofsortedcoloumn, inputparameter.noofaggregation,queryplan.cachedplansize,queryplan.compilememory,queryplan.cputime, queryplan.compiletime,mistake.estimatedpagescached,queryplan.sizeofnodes,queryplan.executiontime FROM asmathesis.inputparameter inner join  queryplan on inputparameter.id=queryplan.idofinputparameter inner join mistake on inputparameter.id=mistake.idinputparameter";

		ResultSet resultset;
		java.sql.Statement statement;
		statement = conn.createStatement();
		resultset = statement.executeQuery(table_selection);
		while (resultset.next()) {
			QueryInputParameters QIP = new QueryInputParameters(resultset.getInt("noofnestedsubqueries"),
					resultset.getInt("noofselectionpredictes"), resultset.getInt("noofequalityselectionpredicate"),
					resultset.getInt("noofnonequalityselectionpredicate"), resultset.getInt("noofjoins"),
					resultset.getInt("noofequijoinpredicate"), resultset.getInt("noofnonequijoinpredicate"),
					resultset.getInt("noofsortedcoloumn"), resultset.getInt("noofaggregation"));
			SelectedFeature SF = new SelectedFeature(resultset.getInt("cachedplansize"),
					resultset.getInt("compilememory"), resultset.getInt("cputime"), resultset.getInt("compiletime"),
					resultset.getInt("estimatedpagescached"), resultset.getInt("sizeofnodes"),
					resultset.getDouble("executiontime"));
			InputAndSelectedFeatures ISF = new InputAndSelectedFeatures(SF, QIP);
			inputandSelected.add(ISF);
		}
		return inputandSelected;

	}

}
