package com.asma.CBR;

public class CenteriodPointOfCluster {
	private double numberOfNestedSubQueries;
	private double numberOfSelectionPredicates;
	private double numberOfequalitySelectionPredicate;
	private double numberOfnonequalitySelectionPredicate;
	private double numberOfJoins;
	private double numberOfEquiJoinsPredicate;
	private double numberOfNonEquiJoinPredicate;
	private double numberOfSortedColoumn;
	private double numberOfAggregation;

	public CenteriodPointOfCluster(double numberOfNestedSubQueries, double numberOfSelectionPredicates,
			double numberOfequalitySelectionPredicate, double numberOfnonequalitySelectionPredicate,
			double numberOfJoins, double numberOfEquiJoinsPredicate, double numberOfNonEquiJoinPredicate,
			double numberOfSortedColoumn, double numberOfAggregation) {

		this.numberOfNestedSubQueries = numberOfNestedSubQueries;
		this.numberOfSelectionPredicates = numberOfSelectionPredicates;
		this.numberOfequalitySelectionPredicate = numberOfequalitySelectionPredicate;
		this.numberOfnonequalitySelectionPredicate = numberOfnonequalitySelectionPredicate;
		this.numberOfJoins = numberOfJoins;
		this.numberOfEquiJoinsPredicate = numberOfEquiJoinsPredicate;
		this.numberOfNonEquiJoinPredicate = numberOfNonEquiJoinPredicate;
		this.numberOfSortedColoumn = numberOfSortedColoumn;
		this.numberOfAggregation = numberOfAggregation;
	}

	public double getNumberOfNestedSubQueries() {
		return numberOfNestedSubQueries;
	}

	public void setNumberOfNestedSubQueries(double numberOfNestedSubQueries) {
		this.numberOfNestedSubQueries = numberOfNestedSubQueries;
	}

	public double getNumberOfSelectionPredicates() {
		return numberOfSelectionPredicates;
	}

	public void setNumberOfSelectionPredicates(double numberOfSelectionPredicates) {
		this.numberOfSelectionPredicates = numberOfSelectionPredicates;
	}

	public double getNumberOfequalitySelectionPredicate() {
		return numberOfequalitySelectionPredicate;
	}

	public void setNumberOfequalitySelectionPredicate(double numberOfequalitySelectionPredicate) {
		this.numberOfequalitySelectionPredicate = numberOfequalitySelectionPredicate;
	}

	public double getNumberOfnonequalitySelectionPredicate() {
		return numberOfnonequalitySelectionPredicate;
	}

	public void setNumberOfnonequalitySelectionPredicate(double numberOfnonequalitySelectionPredicate) {
		this.numberOfnonequalitySelectionPredicate = numberOfnonequalitySelectionPredicate;
	}

	public double getNumberOfJoins() {
		return numberOfJoins;
	}

	public void setNumberOfJoins(double numberOfJoins) {
		this.numberOfJoins = numberOfJoins;
	}

	public double getNumberOfEquiJoinsPredicate() {
		return numberOfEquiJoinsPredicate;
	}

	public void setNumberOfEquiJoinsPredicate(double numberOfEquiJoinsPredicate) {
		this.numberOfEquiJoinsPredicate = numberOfEquiJoinsPredicate;
	}

	public double getNumberOfNonEquiJoinPredicate() {
		return numberOfNonEquiJoinPredicate;
	}

	public void setNumberOfNonEquiJoinPredicate(double numberOfNonEquiJoinPredicate) {
		this.numberOfNonEquiJoinPredicate = numberOfNonEquiJoinPredicate;
	}

	public double getNumberOfSortedColoumn() {
		return numberOfSortedColoumn;
	}

	public void setNumberOfSortedColoumn(double numberOfSortedColoumn) {
		this.numberOfSortedColoumn = numberOfSortedColoumn;
	}

	public double getNumberOfAggregation() {
		return numberOfAggregation;
	}

	public void setNumberOfAggregation(double numberOfAggregation) {
		this.numberOfAggregation = numberOfAggregation;
	}

	@Override
	public String toString() {
		return "CenteriodPointOfCluster [numberOfNestedSubQueries=" + numberOfNestedSubQueries
				+ ", numberOfSelectionPredicates=" + numberOfSelectionPredicates
				+ ", numberOfequalitySelectionPredicate=" + numberOfequalitySelectionPredicate
				+ ", numberOfnonequalitySelectionPredicate=" + numberOfnonequalitySelectionPredicate
				+ ", numberOfJoins=" + numberOfJoins + ", numberOfEquiJoinsPredicate=" + numberOfEquiJoinsPredicate
				+ ", numberOfNonEquiJoinPredicate=" + numberOfNonEquiJoinPredicate + ", numberOfSortedColoumn="
				+ numberOfSortedColoumn + ", numberOfAggregation=" + numberOfAggregation + "]";
	}
	

}
