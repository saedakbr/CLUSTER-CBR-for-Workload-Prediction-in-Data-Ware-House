package com.asma.CBR;

public class SelectedFeature {
	private int cachedPlanSize = 0;
	private int compileMemory = 0;
	private int cpuTime = 0;
	private int compileTime = 0;
	private int estimatedPages = 0;
	private int sizeOfNodes = 0;
	private double executionTime = 0.0;
	private double totalPercentage=0.0;
	private String classes = null;

	public SelectedFeature() {

	}
	

	public SelectedFeature(int cachedPlanSize, int compileMemory, int cpuTime, int compileTime, int estimatedPages,
			int sizeOfNodes, double executionTime) {
		
		this.cachedPlanSize = cachedPlanSize;
		this.compileMemory = compileMemory;
		this.cpuTime = cpuTime;
		this.compileTime = compileTime;
		this.estimatedPages = estimatedPages;
		this.sizeOfNodes = sizeOfNodes;
		this.executionTime = executionTime;
	}

	public SelectedFeature(int cachedPlanSize, int compileMemory, int cpuTime, int compileTime, int estimatedPages,
			int sizeOfNodes, double executionTime, String classes) {

		this.cachedPlanSize = cachedPlanSize;
		this.compileMemory = compileMemory;
		this.cpuTime = cpuTime;
		this.compileTime = compileTime;
		this.estimatedPages = estimatedPages;
		this.sizeOfNodes = sizeOfNodes;
		this.executionTime = executionTime;
		this.classes = classes;
	}

	public int getCachedPlanSize() {
		return cachedPlanSize;
	}

	public void setCachedPlanSize(int cachedPlanSize) {
		this.cachedPlanSize = cachedPlanSize;
	}

	public int getCompileMemory() {
		return compileMemory;
	}

	public void setCompileMemory(int compileMemory) {
		this.compileMemory = compileMemory;
	}

	public int getCpuTime() {
		return cpuTime;
	}

	public void setCpuTime(int cpuTime) {
		this.cpuTime = cpuTime;
	}

	public int getCompileTime() {
		return compileTime;
	}

	public void setCompileTime(int compileTime) {
		this.compileTime = compileTime;
	}

	public int getEstimatedPages() {
		return estimatedPages;
	}

	public void setEstimatedPages(int estimatedPages) {
		this.estimatedPages = estimatedPages;
	}

	public int getSizeOfNodes() {
		return sizeOfNodes;
	}

	public void setSizeOfNodes(int sizeOfNodes) {
		this.sizeOfNodes = sizeOfNodes;
	}

	public double getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(double executionTime) {
		this.executionTime = executionTime;
	}

	public String getClasses() {
		return classes;
	}

	public void setClasses(String classes) {
		this.classes = classes;
	}

	public double getTotalPercentage() {
		return totalPercentage;
	}

	public void setTotalPercentage(double totalPercentage) {
		this.totalPercentage = totalPercentage;
	}

}
