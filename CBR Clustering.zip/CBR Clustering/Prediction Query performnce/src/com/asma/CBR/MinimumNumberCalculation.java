package com.asma.CBR;

public class MinimumNumberCalculation {
	private SelectedFeature selectedfeature;
	private double eculdainDistance;
	public MinimumNumberCalculation(SelectedFeature selectedfeature, double eculdainDistance) {
		this.selectedfeature = selectedfeature;
		this.eculdainDistance = eculdainDistance;
	}
	public SelectedFeature getSelectedfeature() {
		return selectedfeature;
	}
	public void setSelectedfeature(SelectedFeature selectedfeature) {
		this.selectedfeature = selectedfeature;
	}
	public double getEculdainDistance() {
		return eculdainDistance;
	}
	public void setEculdainDistance(double eculdainDistance) {
		this.eculdainDistance = eculdainDistance;
	}
	

}
