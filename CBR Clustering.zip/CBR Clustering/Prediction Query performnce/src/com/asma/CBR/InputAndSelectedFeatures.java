package com.asma.CBR;

import com.asma.thesis.QueryInputParameters;

public class InputAndSelectedFeatures {
	private SelectedFeature selctedfeature;
	QueryInputParameters queryInputParameter;
	private int cluster;

	public InputAndSelectedFeatures(SelectedFeature selctedfeature, QueryInputParameters queryInputParameter) {
		this.selctedfeature = selctedfeature;
		this.queryInputParameter = queryInputParameter;
	}

	public InputAndSelectedFeatures(QueryInputParameters queryInputParameter, SelectedFeature selctedfeature,
			int cluster) {
		this.selctedfeature = selctedfeature;
		this.queryInputParameter = queryInputParameter;
		this.cluster = cluster;
	}

	public SelectedFeature getSelctedfeature() {
		return selctedfeature;
	}

	public void setSelctedfeature(SelectedFeature selctedfeature) {
		this.selctedfeature = selctedfeature;
	}

	public QueryInputParameters getQueryInputParameter() {
		return queryInputParameter;
	}

	public void setQueryInputParameter(QueryInputParameters queryInputParameter) {
		this.queryInputParameter = queryInputParameter;
	}

	public int getCluster() {
		return cluster;
	}

	public void setCluster(int cluster) {
		this.cluster = cluster;
	}

}
