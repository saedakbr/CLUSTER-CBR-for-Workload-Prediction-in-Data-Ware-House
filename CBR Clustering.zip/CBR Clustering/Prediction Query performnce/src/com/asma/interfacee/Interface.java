package com.asma.interfacee;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.asma.connection.Mysqlconnection;
import com.asma.thesis.QueryInputParameters;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JComboBox;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class Interface extends JFrame {

	private JPanel contentPane;
	private JTextField Querry;
	private JTextField noOfSelectionPredicate;
	private JTextField noOfNestedSubQueries;
	private JTextField noOfEqualitySelectionPedicate;
	private JTextField noOfNonEqualitySelection;
	private JTextField noOfJoins;
	private JTextField noOfEquiJoins;
	private JTextField nonOfNonEquiJoinPredicate;
	private JTextField noOfSortedColoum;
	private JTextField noOFAgregatedColoumn;
	private JScrollPane scrollPane;
	private JList listQIP;
	private Connection conn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 */
	public Interface() throws SQLException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 782, 445);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Query Performance Predictor");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(lblNewLabel.getFont().deriveFont(lblNewLabel.getFont().getSize() + 4f));
		lblNewLabel.setForeground(Color.MAGENTA);
		lblNewLabel.setBounds(268, 11, 230, 27);
		contentPane.add(lblNewLabel);

		JLabel lblQuery = new JLabel("Query");
		lblQuery.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblQuery.setForeground(Color.MAGENTA);
		lblQuery.setBounds(276, 88, 57, 27);
		contentPane.add(lblQuery);

		Querry = new JTextField();
		Querry.setBounds(332, 56, 424, 92);
		contentPane.add(Querry);
		Querry.setColumns(10);

		JLabel lblNoOf = new JLabel("no of selection Predicate");
		lblNoOf.setBounds(424, 162, 118, 14);
		contentPane.add(lblNoOf);

		noOfSelectionPredicate = new JTextField();
		noOfSelectionPredicate.setBounds(543, 159, 40, 20);
		contentPane.add(noOfSelectionPredicate);
		noOfSelectionPredicate.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("noofNestedQueries");
		lblNewLabel_1.setBounds(272, 165, 102, 14);
		contentPane.add(lblNewLabel_1);

		noOfNestedSubQueries = new JTextField();
		noOfNestedSubQueries.setBounds(371, 159, 49, 20);
		contentPane.add(noOfNestedSubQueries);
		noOfNestedSubQueries.setColumns(10);

		JLabel lblNoOfEqu = new JLabel("No of equ selct pedicate");
		lblNoOfEqu.setBounds(593, 162, 129, 14);
		contentPane.add(lblNoOfEqu);

		noOfEqualitySelectionPedicate = new JTextField();
		noOfEqualitySelectionPedicate.setBounds(716, 159, 40, 20);
		contentPane.add(noOfEqualitySelectionPedicate);
		noOfEqualitySelectionPedicate.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("noOfNonEqulitySelection");
		lblNewLabel_2.setBounds(268, 197, 118, 14);
		contentPane.add(lblNewLabel_2);

		noOfNonEqualitySelection = new JTextField();
		noOfNonEqualitySelection.setBounds(393, 194, 40, 20);
		contentPane.add(noOfNonEqualitySelection);
		noOfNonEqualitySelection.setColumns(10);

		JLabel lblNoOfJoins = new JLabel("no of Joins");
		lblNoOfJoins.setBounds(443, 197, 55, 14);
		contentPane.add(lblNoOfJoins);

		noOfJoins = new JTextField();
		noOfJoins.setBounds(499, 194, 43, 20);
		contentPane.add(noOfJoins);
		noOfJoins.setColumns(10);

		JLabel lblNewLabel_3 = new JLabel("equiJoinpred");
		lblNewLabel_3.setBounds(553, 197, 61, 14);
		contentPane.add(lblNewLabel_3);

		noOfEquiJoins = new JTextField();
		noOfEquiJoins.setBounds(618, 194, 40, 20);
		contentPane.add(noOfEquiJoins);
		noOfEquiJoins.setColumns(10);

		JLabel lblNoofnonequi = new JLabel("noofnonEqui");
		lblNoofnonequi.setBounds(661, 197, 73, 14);
		contentPane.add(lblNoofnonequi);

		nonOfNonEquiJoinPredicate = new JTextField();
		nonOfNonEquiJoinPredicate.setBounds(726, 194, 40, 20);
		contentPane.add(nonOfNonEquiJoinPredicate);
		nonOfNonEquiJoinPredicate.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("noOfSortColoum");
		lblNewLabel_4.setBounds(335, 222, 85, 14);
		contentPane.add(lblNewLabel_4);

		noOfSortedColoum = new JTextField();
		noOfSortedColoum.setBounds(453, 219, 34, 20);
		contentPane.add(noOfSortedColoum);
		noOfSortedColoum.setColumns(10);

		JLabel lblAggregatedcol = new JLabel("noofaggregatedcol");
		lblAggregatedcol.setBounds(509, 222, 95, 14);
		contentPane.add(lblAggregatedcol);

		noOFAgregatedColoumn = new JTextField();
		noOFAgregatedColoumn.setBounds(609, 222, 49, 20);
		contentPane.add(noOFAgregatedColoumn);
		noOFAgregatedColoumn.setColumns(10);
		
		JLabel lblSelectItem = new JLabel("Select Item");
		lblSelectItem.setBounds(499, 335, 82, 14);
		contentPane.add(lblSelectItem);
		scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension(100, 2));
		scrollPane.setMaximumSize(new Dimension(100, 22707));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 0, 256, 440);
		DefaultListModel<QueryInputParameters> queryInputParameterModel = new DefaultListModel<QueryInputParameters>();
		listQIP = new JList(queryInputParameterModel);
		contentPane.add(scrollPane);
		readinput(queryInputParameterModel);
		scrollPane.setViewportView(listQIP);
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(593, 332, 151, 20);
		contentPane.add(comboBox);
		 comboBox.setEditable(true);
	        comboBox.addItem("Accuracy");
	        comboBox.addItem("Precision");
	        
	        JButton btnCheckAccuracy = new JButton("Check Accuracy");
	        btnCheckAccuracy.setBounds(308, 267, 151, 23);
	        contentPane.add(btnCheckAccuracy);
	        
	        JButton btnAddResut = new JButton("Add Result");
	        btnAddResut.setBounds(593, 267, 129, 23);
	        contentPane.add(btnAddResut);
	        
	        JLabel lblPredicationResult = new JLabel("Predication Result");
	        lblPredicationResult.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
	        lblPredicationResult.setForeground(Color.MAGENTA);
	        lblPredicationResult.setBounds(464, 310, 171, 14);
	        contentPane.add(lblPredicationResult);
	        comboBox.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					JComboBox combox=(JComboBox)e.getSource();
					Object selected= combox.getSelectedItem();
					if(selected.toString().equals("item1")){
						System.out.println("Item 1");
					}
				}
			});
		
	}
	public ArrayList<QueryInputParameters> readinput(DefaultListModel<QueryInputParameters> listmodelQIP)
			throws SQLException {
		ArrayList<QueryInputParameters> arrayListQIP = new ArrayList<>();
		String table_selection = "select* from inputparameter";
		conn = Mysqlconnection.connetion();
		ResultSet resultset;
		java.sql.Statement statement;
		statement = conn.createStatement();
		resultset = statement.executeQuery(table_selection);
		while (resultset.next()) {
			QueryInputParameters QIPobject = new QueryInputParameters(resultset.getInt("id"),
					resultset.getString("inputquery"));
			// System.out.println(QIPobject);
			if (listmodelQIP != null)
				listmodelQIP.addElement(QIPobject);
			arrayListQIP.add(QIPobject);
		}
		conn.close();
		return arrayListQIP;

	}
}
