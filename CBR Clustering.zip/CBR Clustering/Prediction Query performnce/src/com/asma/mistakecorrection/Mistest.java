//package com.asma.mistakecorrection;
//
//import java.io.ByteArrayInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.util.ArrayList;
//import java.util.Date;
//
//import javax.swing.DefaultListModel;
//
//import org.jdom2.Document;
//import org.jdom2.Element;
//import org.jdom2.JDOMException;
//import org.jdom2.filter.ElementFilter;
//import org.jdom2.input.SAXBuilder;
//
//import com.asma.connection.Mysqlconnection;
//import com.asma.connection.sqlconnection;
//import com.asma.thesis.QueryInputParameters;
//import com.asma.thesis.QueryPlan;
//import com.mysql.jdbc.PreparedStatement;
//
//public class Mistest {
//	public static void main(String... arg) throws SQLException, JDOMException, IOException {
//		// addvalues();
//		cal();
//	}
//
//	// public static()
//	public static String calculation(String querry) throws SQLException, JDOMException, IOException {
//		Connection conn = sqlconnection.connection();
//		String showplanQuery = "SET SHOWPLAN_XML ON";
//		String ob = null;
//		if (conn != null) {
//			Date startdate = new Date();
//			// System.out.println("startdate" + startdate);
//			Statement stat = conn.createStatement();
//			stat.execute(showplanQuery);
//
//			stat.execute(querry);
//
//			if (stat.execute(querry)) {
//				ResultSet rs = stat.getResultSet();
//				// String op="<?xml version="1.0" encoding="utf-16"?>";
//
//				while (rs.next()) {
//					ob = (String) rs.getObject(1);
//					// System.out.println(ob);
//
//				}
//
//			}
//
//		}
//
//		return ob;
//
//	}
//
//	public static int estimatedpagescached(String querry) throws JDOMException, IOException, SQLException {
//		SAXBuilder builder = new SAXBuilder();
//		Document doc = null;
//		String xml = calculation(querry);
//
//		InputStream stream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
//		doc = builder.build(stream);
//		Element root = doc.getRootElement();
//
//		ElementFilter elementfilter2 = new ElementFilter("OptimizerHardwareDependentProperties");
//
//		String EstimatedPagesCached = null;
//
//		for (Element queryPlan2 : root.getDescendants(elementfilter2)) {
//
//			EstimatedPagesCached = queryPlan2.getAttributeValue("EstimatedPagesCached");
//
//		}
//
//		int estimatedpagescached = Integer.valueOf(EstimatedPagesCached);
//		// System.out.println(estimatedpagescached);
//
//		return estimatedpagescached;
//	}
//
//	public static ArrayList<QueryInputParameters> readinput() throws SQLException {
//		ArrayList<QueryInputParameters> arrayListQIP = new ArrayList<>();
//		String table_selection = "select* from inputparameter";
//		Connection conn = Mysqlconnection.connetion();
//		ResultSet resultset;
//		java.sql.Statement statement;
//		statement = conn.createStatement();
//		resultset = statement.executeQuery(table_selection);
//		int i = 0;
//		while (resultset.next()) {
//			QueryInputParameters QIPobject = new QueryInputParameters(resultset.getInt("id"),
//					resultset.getString("inputquery"));
//			i++;
//			// System.out.println(i+" "+resultset.getInt("id"));
//
//			arrayListQIP.add(QIPobject);
//		}
//		conn.close();
//		return arrayListQIP;
//
//	}
//
//	public static ArrayList<mis> miscal() throws SQLException, JDOMException, IOException {
//		ArrayList<QueryInputParameters> QIP = readinput();
//		ArrayList<mis> mistlist = new ArrayList<>();
//		for (int i = 0; i < QIP.size(); i++) {
//			mis m = new mis(QIP.get(i).getId(), estimatedpagescached(QIP.get(i).getQuery()));
//			mistlist.add(m);
//
//		}
//		return mistlist;
//	}
//
//	public static void addvalues() throws SQLException, JDOMException, IOException {
//		ArrayList<mis> list = miscal();
//
//		Connection conn = Mysqlconnection.connetion();
//		String insertingNodeInput = "insert into mistake (estimatedpagescached,idinputparameter)" + "values (?,?)";
//		PreparedStatement statement = (PreparedStatement) conn.prepareStatement(insertingNodeInput);
//
//		for (mis m : list) {
//			System.out.println(m.getEstimatedpagesccahed());
//			statement.setInt(1, m.getEstimatedpagesccahed());
//			statement.setInt(2, m.getId());
//			statement.execute();
//
//		}
//		System.out.println("added");
//
//	}
//
//	public static void cal() throws SQLException, JDOMException, IOException {
//		ArrayList<QueryInputParameters> qiList = readinput();
//		Connection connc = null;
//		Connection conn = null;
//		for (int i = 0; i < qiList.size(); i++) {
//			conn = sqlconnection.connection();
//			String showplanQuery = "SET SHOWPLAN_XML ON";
//			String ob = null;
//			if (conn != null) {
//				Date startdate = new Date();
//				// System.out.println("startdate" + startdate);
//				Statement stat = conn.createStatement();
//				stat.execute(showplanQuery);
//
//				stat.execute(qiList.get(0).getQuery());
//
//				if (stat.execute(qiList.get(0).getQuery())) {
//					ResultSet rs = stat.getResultSet();
//					// String op="<?xml version="1.0" encoding="utf-16"?>";
//
//					while (rs.next()) {
//						ob = (String) rs.getObject(1);
//						// System.out.println(ob);
//
//					}
//
//				}
//				System.out.println(ob);
//
//			}
//			System.out.println("cal");
//			SAXBuilder builder = new SAXBuilder();
//			Document doc = null;
//			// String xml = calculation(querry);
//
//			InputStream stream = new ByteArrayInputStream(ob.getBytes("UTF-8"));
//			doc = builder.build(stream);
//			Element root = doc.getRootElement();
//
//			ElementFilter elementfilter2 = new ElementFilter("OptimizerHardwareDependentProperties");
//
//			String EstimatedPagesCached = null;
//
//			for (Element queryPlan2 : root.getDescendants(elementfilter2)) {
//
//				EstimatedPagesCached = queryPlan2.getAttributeValue("EstimatedPagesCached");
//
//			}
//
//			int estimatedpagescached = Integer.valueOf(EstimatedPagesCached);
//			EstimatedPagesCached = null;
//			System.out.println(estimatedpagescached);
//			connc = Mysqlconnection.connetion();
//			String insertingNodeInput = "insert into mistake (estimatedpagescached,idinputparameter)" + "values (?,?)";
//			PreparedStatement statement = (PreparedStatement) connc.prepareStatement(insertingNodeInput);
//
//			statement.setInt(1, estimatedpagescached);
//			statement.setInt(2, qiList.get(i).getId());
//
//			statement.execute();
//			System.out.println("id " + qiList.get(i).getId() + "  added" + "        " + i);
//
//		}
//		conn.close();
//		connc.close();
//	}
//}
