package com.asma.mistakecorrection;

public class mis {
	int id = 0;
	int estimatedpagesccahed = 0;

	public mis(int id, int estimatedpagesccahed) {

		this.id = id;
		this.estimatedpagesccahed = estimatedpagesccahed;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEstimatedpagesccahed() {
		return estimatedpagesccahed;
	}

	public void setEstimatedpagesccahed(int estimatedpagesccahed) {
		this.estimatedpagesccahed = estimatedpagesccahed;
	}

}
