package com.asma.Simulation;

public interface MonteCarlo {
	int randomAlgorithm() throws Exception;
	int randomAlgorithm1() throws Exception;

}
