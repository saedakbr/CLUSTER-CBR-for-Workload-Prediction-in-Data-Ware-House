package com.asma.Simulation;

import java.sql.SQLException;

public interface LasVegas {
	//int randomAlgorithm(boolean condition) throws SQLException;

	int randomAlgorithm() throws Exception;
	
}
