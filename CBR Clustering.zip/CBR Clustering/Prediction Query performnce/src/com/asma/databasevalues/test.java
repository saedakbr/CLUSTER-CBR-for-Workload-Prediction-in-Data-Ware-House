//import java.io.ByteArrayInputStream;
//import java.io.InputStream;
//import java.util.ArrayList;
//
//import org.jdom2.Document;
//import org.jdom2.Element;
//import org.jdom2.input.SAXBuilder;
//
//import com.asma.thesis.Node;
//
//// System.out.println(xml);
//		InputStream inputstream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
//		doc = builder.build(inputstream);
//		// System.out.println(doc);
//		Element root = doc.getRootElement();
//		ArrayList<Element> elementList = queryNodePlan(builder, doc, xml, inputstream, root);
//		for (int i = 0; i < elementList.size(); i++) {
//			String nodeid = elementList.get(i).getAttributeValue("NodeId");
//			String PhysicalOp = elementList.get(i).getAttributeValue("PhysicalOp");
//			String LogicalOp = elementList.get(i).getAttributeValue("LogicalOp");
//			String EstimateRows = elementList.get(i).getAttributeValue("EstimateRows");
//			double estimaterows= Double.parseDouble(EstimateRows);
//			String EstimateIO = elementList.get(i).getAttributeValue("EstimateIO");
//			double estimateio=Double.parseDouble(EstimateIO);
//			String EstimateCPU = elementList.get(i).getAttributeValue("EstimateCPU");
//			double estimatecpu=Double.parseDouble(EstimateCPU);
//			String AvgRowSize = elementList.get(i).getAttributeValue("AvgRowSize");
//			double avgrowsize=Double.parseDouble(AvgRowSize);
//			String EstimatedTotalSubtreeCost = elementList.get(i).getAttributeValue("EstimatedTotalSubtreeCost");
//			double estimatedtotalsubtreecost=Double.parseDouble(AvgRowSize);
//			String TableCardinality = elementList.get(i).getAttributeValue("TableCardinality");			
//			String Parallel = elementList.get(i).getAttributeValue("Parallel");
//			double parallel= Double.parseDouble(Parallel);
//			String EstimateRebinds = elementList.get(i).getAttributeValue("EstimateRebinds");
//			double estimatedrebinds=Double.parseDouble(EstimateRebinds);
//			String EstimateRewinds = elementList.get(i).getAttributeValue("EstimateRewinds");
//			double estimaterewinds=Double.parseDouble(EstimateRewinds);
//			String EstimatedExecutionmode = elementList.get(i).getAttributeValue("EstimatedExecutionMode");
//			//double estimatedexecutionmode=Double.parseDouble(EstimatedExecutionmode);		
//	//System.out.println(EstimatedExecutionmode);
//			node = new Node(PhysicalOp, LogicalOp, estimaterows, estimateio, estimatecpu, avgrowsize, estimatedtotalsubtreecost, TableCardinality, parallel, estimaterewinds, estimatedrebinds, EstimatedExecutionmode);
//				nodelist.add(node);
//			
//
//		}
//		return nodelist;
//	}