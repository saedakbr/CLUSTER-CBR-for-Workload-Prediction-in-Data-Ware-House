package com.asma.databasevalues;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.filter.ElementFilter;
import org.jdom2.input.SAXBuilder;

import com.asma.connection.sqlconnection;
import com.asma.thesis.Node;
import com.asma.thesis.QueryInputParameters;
import com.asma.thesis.QueryPlan;

import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.expression.BinaryExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.Function;
import net.sf.jsqlparser.expression.operators.relational.Between;
import net.sf.jsqlparser.expression.operators.relational.InExpression;
import net.sf.jsqlparser.expression.operators.relational.MinorThan;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.select.FromItem;
import net.sf.jsqlparser.statement.select.PlainSelect;
import net.sf.jsqlparser.statement.select.Select;
import net.sf.jsqlparser.statement.select.SelectBody;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;
import net.sf.jsqlparser.statement.select.SubSelect;

public class Connecting_class {
	static Connection conn = null;
	static String showplanQuery = "SET SHOWPLAN_XML ON";
	static String ob = null;
	private int noOfSelects = 0;
	private int noOfUpdates = 0;
	private int noOfSelectionPredicates = 0;
	private int noOfEqualitySelectionPredicates = 0;
	private int noOfAggregates = 0;
	private int noOfAggregateColumns = 0;
	private int noOfJoins = 0;
	static double executionTime = 0.0;

	// public static void main(String[] arg)
	// throws SQLException, JDOMException, IOException, ClassNotFoundException,
	// JSQLParserException {
	// // Mysqlconnection.connetion();
//	 String querry = "SELECT customer.C_CustKey, customer.C_Name,
//	lineitem.L_PartKey, lineitem.L_SuppKey, orders.O_CustKey FROM customer
//	 INNER JOIN orders ON customer.C_CustKey = orders.O_CustKey INNER JOIN
//	 lineitem ON orders.O_OrderKey = lineitem.L_OrderKey";
	// inputParameters(querry);
	// String xmlinput = calculation(querry);
	// //System.out.println(xmlinput);
	// //System.out.println(executionTime);
	// calculateQueryNodePlan(querry);
	// ArrayList<Node> list= calculateQueryNodePlan(querry);
	// for(int i=0;i<list.size();i++){
	// System.out.println(list.get(i));
	// }
	//
	// QueryInputParameters qip=inputParameters(querry);
	// System.out.println(qip);
	//// these three can be added to database
	// QueryPlan plan= queryPlan(xmlinput,executionTime);
	// System.out.println(plan);
	// }

	public static String calculation(String querry) throws SQLException, JDOMException, IOException {
		conn = sqlconnection.connection();
		if (conn != null) {
			Date startdate = new Date();
			// System.out.println("startdate" + startdate);
			Statement stat = conn.createStatement();
			stat.execute(showplanQuery);
			double start = System.currentTimeMillis();
			double end = 0;
			stat.execute(querry);
			end = System.currentTimeMillis();
			if (stat.execute(querry)) {
				ResultSet rs = stat.getResultSet();
				// String op="<?xml version="1.0" encoding="utf-16"?>";

				while (rs.next()) {
					ob = (String) rs.getObject(1);
				}

			}
			// System.out.println("Execution time" + (end - start));
			double a = (end - start);
			executionTime = (a);
			conn.close();
		}

		return ob;

	}

	private static void exploreSelectStatement(Select select, Connecting_class features) {
		features.setNoOfSelects(features.getNoOfSelects() + 1);
		SelectBody body = select.getSelectBody();
		if (body != null && body instanceof PlainSelect) {
			PlainSelect pSelect = (PlainSelect) body;
			FromItem from = pSelect.getFromItem();
			// System.out.println(from);
			for (SelectItem item : pSelect.getSelectItems()) {
				SelectExpressionItem seItem = (SelectExpressionItem) item;
				if (seItem.getExpression() instanceof Function)
					exploreFunction((Function) seItem.getExpression(), features);
			}
			exploreExpression(pSelect.getWhere(), features);
			exploreExpression(pSelect.getHaving(), features);
			if (pSelect.getHaving() != null) {
				features.setNoOfAggregates(features.getNoOfAggregates() + 1);
			}
			if (pSelect.getGroupByColumnReferences() != null) {
				features.setNoOfAggregates(features.getNoOfAggregates() + 1);
				features.setNoOfAggregateColumns(
						features.getNoOfAggregateColumns() + pSelect.getGroupByColumnReferences().size());
			}
			if (pSelect.getJoins() != null)
				features.setNoOfJoins(features.getNoOfJoins() + pSelect.getJoins().size());
		}
	}

	private static void exploreFunction(Function ftn, Connecting_class features) {
		if (ftn.getParameters().getExpressions().get(0) instanceof Function) {
			exploreFunction((Function) ftn.getParameters().getExpressions().get(0), features);
		}
	}

	private static void exploreSubSelectStatement(SubSelect subSelect, Connecting_class features) {
		features.setNoOfSelects(features.getNoOfSelects() + 1);
		SelectBody body = subSelect.getSelectBody();
		if (body != null && body instanceof PlainSelect) {
			PlainSelect pSelect = (PlainSelect) body;
			FromItem from = pSelect.getFromItem();
			// System.out.println(from);
			exploreExpression(pSelect.getWhere(), features);
			exploreExpression(pSelect.getHaving(), features);
			if (pSelect.getJoins() != null)
				features.setNoOfJoins(features.getNoOfJoins() + pSelect.getJoins().size());
		}
	}

	private static void exploreExpression(Expression exp, Connecting_class features) {
		if (exp == null)
			return;
		// System.out.println("exploring expression: " + exp);
		if (exp instanceof Between) {
			features.setNoOfSelectionPredicates(features.getNoOfSelectionPredicates() + 1);
			Between between = (Between) exp;
			// System.out.println(between);
		} else if (exp instanceof InExpression) {
			InExpression inExp = (InExpression) exp;
			features.setNoOfSelectionPredicates(features.getNoOfSelectionPredicates() + 1);
			// System.out.println("IN expression: " +
			// inExp.getRightItemsList().getClass());
			if (inExp.getRightItemsList() instanceof SubSelect)
				exploreSubSelectStatement((SubSelect) inExp.getRightItemsList(), features);
		} else if (exp instanceof BinaryExpression) {
			BinaryExpression bExpression = (BinaryExpression) exp;
			if (bExpression instanceof MinorThan)

				// System.out.println("Less than");
				features.setNoOfSelectionPredicates(features.getNoOfSelectionPredicates() + 1);
			// System.out.println(bExpression.getRightExpression());
			Expression leftExpression = bExpression.getLeftExpression();
			Expression rightExpression = bExpression.getRightExpression();
			exploreExpression(leftExpression, features);
			exploreExpression(rightExpression, features);
		} else if (exp instanceof SubSelect) {
			exploreSubSelectStatement((SubSelect) exp, features);
		} else if (exp instanceof MinorThan) {
			MinorThan having = (MinorThan) exp;
			// System.out.println("\nhaving : " + having.getLeftExpression());
			if (having.getLeftExpression() instanceof Function) {
				exploreFunction((Function) having.getLeftExpression(), features);
			}
		}
	}

	public int getNoOfSelectionPredicates() {
		return noOfSelectionPredicates;
	}

	public void setNoOfSelectionPredicates(int noOfPredicates) {
		this.noOfSelectionPredicates = noOfPredicates;
	}

	public int getNoOfUpdates() {
		return noOfUpdates;
	}

	public void setNoOfUpdates(int noOfUpdates) {
		this.noOfUpdates = noOfUpdates;
	}

	public int getNoOfSelects() {
		return noOfSelects;
	}

	public void setNoOfSelects(int noOfSelects) {
		this.noOfSelects = noOfSelects;
	}

	public int getNoOfAggregates() {
		return noOfAggregates;
	}

	public void setNoOfAggregates(int noOfAggregates) {
		this.noOfAggregates = noOfAggregates;
	}

	public int getNoOfAggregateColumns() {
		return noOfAggregateColumns;
	}

	public void setNoOfAggregateColumns(int noOfAggregateColumns) {
		this.noOfAggregateColumns = noOfAggregateColumns;
	}

	public int getNoOfJoins() {
		return noOfJoins;
	}

	public void setNoOfJoins(int noOfJoins) {
		this.noOfJoins = noOfJoins;
	}

	public int getNoOfEqualitySelectionPredicates() {
		return noOfEqualitySelectionPredicates;
	}

	public void setNoOfEqualitySelectionPredicates(int noOfEqualitySelectionPredicates) {
		this.noOfEqualitySelectionPredicates = noOfEqualitySelectionPredicates;
	}

	public static QueryInputParameters inputParameters(String query) throws JSQLParserException {
		// ArrayList<QueryInputParameters> listQueryInputParameter= new
		// ArrayList<>();
		Connecting_class features = new Connecting_class();
		net.sf.jsqlparser.statement.Statement stmt = CCJSqlParserUtil.parse(query);
		if (stmt instanceof Select) {
			exploreSelectStatement((Select) stmt, features);
		}

		// System.out.println("Selects : " + features.getNoOfSelects());
		// System.out.println("Predicates : " +
		// features.getNoOfSelectionPredicates());
		// System.out.println("Updates : " + features.getNoOfUpdates());
		// System.out.println("Aggregates : " + features.getNoOfAggregates());
		// System.out.println("Aggregate Columns : " +
		// features.getNoOfAggregateColumns());
		// System.out.println("No of Joins : " + features.getNoOfJoins());
		int numberofequality = 0;
		int numberofnonequality = 0;
		int numberofequijoin = 0;
		int numberofnonequijoin = 0;
		QueryInputParameters queryInputParameters = new QueryInputParameters(query, features.getNoOfSelects(),
				features.getNoOfSelectionPredicates(), numberofequality, numberofnonequality, features.getNoOfJoins(),
				numberofequijoin, numberofnonequijoin, features.getNoOfAggregateColumns(),
				features.getNoOfAggregates());
		return queryInputParameters;

	}

	public static ArrayList<Element> queryNodePlan(SAXBuilder builder, Document doc, String xml,
			InputStream inputstream, Element root) {
		ArrayList<Element> listElement = new ArrayList<>();
		ElementFilter filter = new ElementFilter("RelOp");
		for (Element e : root.getDescendants(filter)) {
			listElement.add(e);
		}
		return listElement;

	}

	public static ArrayList<Node> calculateQueryNodePlan(String query) throws JDOMException, IOException, SQLException {
		ArrayList<Node> nodelist = new ArrayList<>();
		Node node = null;
		SAXBuilder builder = new SAXBuilder();
		Document doc = null;
		String xml = calculation(query);

		// System.out.println(xml);
		InputStream inputstream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
		doc = builder.build(inputstream);
		// System.out.println(doc);
		Element root = doc.getRootElement();
		ArrayList<Element> elementList = queryNodePlan(builder, doc, xml, inputstream, root);
		for (int i = 0; i < elementList.size(); i++) {
			String nodeid = elementList.get(i).getAttributeValue("NodeId");
			String PhysicalOp = elementList.get(i).getAttributeValue("PhysicalOp");
			String LogicalOp = elementList.get(i).getAttributeValue("LogicalOp");
			String EstimateRows = elementList.get(i).getAttributeValue("EstimateRows");
			double estimaterows = Double.parseDouble(EstimateRows);
			String EstimateIO = elementList.get(i).getAttributeValue("EstimateIO");
			double estimateio = Double.parseDouble(EstimateIO);
			String EstimateCPU = elementList.get(i).getAttributeValue("EstimateCPU");
			double estimatecpu = Double.parseDouble(EstimateCPU);
			String AvgRowSize = elementList.get(i).getAttributeValue("AvgRowSize");
			double avgrowsize = Double.parseDouble(AvgRowSize);
			String EstimatedTotalSubtreeCost = elementList.get(i).getAttributeValue("EstimatedTotalSubtreeCost");
			double estimatedtotalsubtreecost = Double.parseDouble(AvgRowSize);
			String TableCardinality = elementList.get(i).getAttributeValue("TableCardinality");
			String Parallel = elementList.get(i).getAttributeValue("Parallel");
			double parallel = Double.parseDouble(Parallel);
			String EstimateRebinds = elementList.get(i).getAttributeValue("EstimateRebinds");
			double estimatedrebinds = Double.parseDouble(EstimateRebinds);
			String EstimateRewinds = elementList.get(i).getAttributeValue("EstimateRewinds");
			double estimaterewinds = Double.parseDouble(EstimateRewinds);
			String EstimatedExecutionmode = elementList.get(i).getAttributeValue("EstimatedExecutionMode");
			// double
			// estimatedexecutionmode=Double.parseDouble(EstimatedExecutionmode);
			// System.out.println(EstimatedExecutionmode);
			node = new Node(PhysicalOp, LogicalOp, estimaterows, estimateio, estimatecpu, avgrowsize,
					estimatedtotalsubtreecost, TableCardinality, parallel, estimaterewinds, estimatedrebinds,
					EstimatedExecutionmode);
			nodelist.add(node);

		}
		return nodelist;
	}

	public static QueryPlan queryPlan(String xml, double executiontime)
			throws JDOMException, IOException, SQLException {
		SAXBuilder builder = new SAXBuilder();
		Document doc = null;
		QueryPlan objqueryplan;
		InputStream stream = new ByteArrayInputStream(xml.getBytes("UTF-8"));
		doc = builder.build(stream);
		Element root = doc.getRootElement();
		ElementFilter elementfilter = new ElementFilter("QueryPlan");
		// System.out.println(elementfilter);
		String NonParallelPlanReason = null;
		String CachedPlanSize = null;
		String Compiletime = null;
		String CompileCpu = null;
		String CompileMemory = null;
		for (Element queryPlan : root.getDescendants(elementfilter)) {
			NonParallelPlanReason = queryPlan.getAttributeValue("NonParallelPlanReason");
			CachedPlanSize = queryPlan.getAttributeValue("CachedPlanSize");
			Compiletime = queryPlan.getAttributeValue("CompileTime");
			CompileCpu = queryPlan.getAttributeValue("CompileCPU");
			CompileMemory = queryPlan.getAttributeValue("CompileMemory");

		}

		int cachedplansize = Integer.valueOf(CachedPlanSize);

		int compiletime = Integer.valueOf(Compiletime);

		int compilecpu = Integer.valueOf(CompileCpu);

		int compilememory = Integer.valueOf(CompileMemory);
		//System.out.println("compile memory" + compilememory);
		// System.out.println("Non parallel plan reason " +
		// NonParallelPlanReason);
		// System.out.println("cached plan size " + CachedPlanSize);
		// System.out.println("Compile Time " + Compiletime);
		// System.out.println("Compile Cpu " + CompileCpu);
		// System.out.println("Compile Memory " + CompileMemory);
		ElementFilter elementfilter1 = new ElementFilter("MemoryGrantInfo");
		String SerialRequiredMemory=null;
		String SerialDesiredMemory= null;
		for(Element queryPlan1: root.getDescendants(elementfilter1)){
			SerialRequiredMemory = queryPlan1.getAttributeValue("SerialRequiredMemory");
			SerialDesiredMemory = queryPlan1.getAttributeValue("SerialDesiredMemory");	
		}
//		Element queryPlan1 = root.getChildren().get(0).getChildren().get(0).getChildren().get(0).getChildren().get(0)
//				.getChildren().get(1).getChildren().get(0);
//		
		//String SerialRequiredMemory = queryPlan1.getAttributeValue("SerialRequiredMemory");
		// System.out.println(SerialRequiredMemory);
		int serialrequiredmemory = Integer.valueOf(SerialRequiredMemory);
		//String SerialDesiredMemory = queryPlan1.getAttributeValue("SerialDesiredMemory");
		int serialdesiredmemory = Integer.valueOf(SerialDesiredMemory);
		// System.out.println("Serial Required Memory " + SerialRequiredMemory);
	 //System.out.println("Serial Desired Memeory " + SerialDesiredMemory);
		
		ElementFilter elementfilter2 = new ElementFilter("OptimizerHardwareDependentProperties");
		String EstimatedAvailableMemoryGrant=null;
		String EstimatedPagesCached=null;
		String EstimatedAvailableDegreeOfParallelism=null;
		
		for(Element queryPlan2: root.getDescendants(elementfilter2)){
			EstimatedAvailableMemoryGrant = queryPlan2.getAttributeValue("EstimatedAvailableMemoryGrant");
			EstimatedPagesCached = queryPlan2.getAttributeValue("EstimatedPagesCached");
			EstimatedAvailableDegreeOfParallelism = queryPlan2
					.getAttributeValue("EstimatedAvailableDegreeOfParallelism");
		
		}
//		Element queryPlan2 = root.getChildren().get(0).getChildren().get(0).getChildren().get(0).getChildren().get(0)
//				.getChildren().get(1).getChildren().get(1);
		// System.out.println(queryPlan2);
		// EstimatedAvailableMemoryGrant = queryPlan2.getAttributeValue("EstimatedAvailableMemoryGrant");
		int estimatedavailablitymemorygrant = Integer.valueOf(EstimatedAvailableMemoryGrant);
		// EstimatedPagesCached = queryPlan2.getAttributeValue("EstimatedPagesCached");
		int estimatedpagescached = Integer.valueOf(EstimatedPagesCached);
 //EstimatedAvailableDegreeOfParallelism = queryPlan2
				//.getAttributeValue("EstimatedAvailableDegreeOfParallelism");
		int estimatedavailiablitydegreeofparallisim = Integer.valueOf(EstimatedAvailableDegreeOfParallelism);
		System.out.println(estimatedavailiablitydegreeofparallisim);
		// System.out.println("Estimated Avaliblity MEmeory Grant " +
		// EstimatedAvailableMemoryGrant);
		// System.out.println("Estimated Pages Cached" + EstimatedPagesCached);
		// System.out.println("Estimated Availablity Degree of parallisim " +
		// EstimatedAvailableDegreeOfParallelism);
		objqueryplan = new QueryPlan(executiontime, NonParallelPlanReason, cachedplansize, compiletime, compilecpu,
				compilememory, serialrequiredmemory, serialdesiredmemory, estimatedavailablitymemorygrant,
				estimatedpagescached, estimatedavailiablitydegreeofparallisim);
		return objqueryplan;
	}
}
