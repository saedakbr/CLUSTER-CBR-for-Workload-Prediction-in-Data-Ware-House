package com.asma.databasevalues;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import org.jdom2.JDOMException;

import com.asma.connection.Mysqlconnection;
import com.asma.thesis.Node;
import com.asma.thesis.QueryInputParameters;
import com.asma.thesis.QueryPlan;
import com.mysql.jdbc.PreparedStatement;

import net.sf.jsqlparser.JSQLParserException;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ListModel;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField queryString;
	private DefaultListModel<QueryInputParameters> queryInputParameterModel = null;
	private JLabel lblNewLabel;
	private JTextField equalityselction;
	private JLabel lblNewLabel_1;
	private JTextField nonequalityselction;
	private JLabel lblEquijoin;
	private JLabel lblNewLabel_2;
	private JTextField equijoin;
	private JTextField nonequijoin;
	private String querry = null;
	private String equalitySelection = null;
	private int equalitySelectionInteger = 0;
	private String nonEqualitySelection = null;
	private int nonequalitySelectionInteger = 0;
	private String equiJoins = null;
	private int equijoinsInteger = 0;
	private String nonEquiJoins = null;
	private int nonequijoininteger = 0;
	private Connection conn;
	private JScrollPane scrollPane;
	private JList listQIP;
	private JTextField numberOfnestedQueries;
	private String numberOfNestedQueries=null;
	private int NONQ=0;
	private JTextField selectionPredicates;
	private String selectionPRedicates=null;
	private int SP=0;
	private JTextField numberofjoin;
	private String numberOfJoin=null;
	private int NOJ=0;
	private JTextField sortcolomn;
	private String sortColomn=null;
	private int SC=0;
	private JTextField aggretedcoloumn;
	private String aggretedColumn=null;
	private int AC=0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 */
	public Main() throws SQLException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblQuerry = new JLabel("Querry");
		lblQuerry.setBounds(311, 27, 46, 14);
		contentPane.add(lblQuerry);

		queryString = new JTextField();
		queryString.setBounds(378, 8, 394, 53);
		contentPane.add(queryString);
		queryString.setColumns(10);

		lblNewLabel = new JLabel("Equality Selection");
		lblNewLabel.setBounds(559, 72, 86, 14);
		contentPane.add(lblNewLabel);

		equalityselction = new JTextField();
		equalityselction.setBounds(666, 72, 86, 20);
		contentPane.add(equalityselction);
		equalityselction.setColumns(10);

		lblNewLabel_1 = new JLabel("Non equality");
		lblNewLabel_1.setBounds(570, 117, 75, 14);
		contentPane.add(lblNewLabel_1);

		nonequalityselction = new JTextField();
		nonequalityselction.setBounds(666, 114, 86, 20);
		contentPane.add(nonequalityselction);
		nonequalityselction.setColumns(10);

		lblEquijoin = new JLabel("Equijoin");
		lblEquijoin.setBounds(570, 159, 46, 14);
		contentPane.add(lblEquijoin);

		lblNewLabel_2 = new JLabel("Non equijoin");
		lblNewLabel_2.setBounds(570, 217, 75, 14);
		contentPane.add(lblNewLabel_2);

		equijoin = new JTextField();
		equijoin.setBounds(666, 156, 86, 20);
		contentPane.add(equijoin);
		equijoin.setColumns(10);

		nonequijoin = new JTextField();
		nonequijoin.setBounds(666, 201, 86, 20);
		contentPane.add(nonequijoin);
		nonequijoin.setColumns(10);
		scrollPane = new JScrollPane();
		scrollPane.setPreferredSize(new Dimension(100, 2));
		scrollPane.setMaximumSize(new Dimension(100, 22707));
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 0, 256, 440);
		queryInputParameterModel = new DefaultListModel<QueryInputParameters>();
		listQIP = new JList(queryInputParameterModel);
		// querry = queryString.getText();
		JButton btnRunQuery = new JButton("Run Query");
		btnRunQuery.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				querry = queryString.getText().toString();
				equalitySelection = equalityselction.getText().toString();
				equalitySelectionInteger = Integer.valueOf(equalitySelection);
				nonEqualitySelection = nonequalityselction.getText().toString();
				nonequalitySelectionInteger = Integer.valueOf(nonEqualitySelection);
				equiJoins = equijoin.getText().toString();
				equijoinsInteger = Integer.valueOf(equiJoins);
				nonEquiJoins = nonequijoin.getText().toString();
				nonequijoininteger = Integer.valueOf(nonEquiJoins);
				numberOfNestedQueries=numberOfnestedQueries.getText().toString();
				NONQ=Integer.valueOf(numberOfNestedQueries);
				selectionPRedicates=selectionPredicates.getText().toString();
				SP=Integer.valueOf(selectionPRedicates);
				numberOfJoin=numberofjoin.getText().toString();
				NOJ=Integer.valueOf(numberOfJoin);
				sortColomn=sortcolomn.getText().toString();
				SC=Integer.valueOf(sortColomn);
				aggretedColumn=aggretedcoloumn.getText().toString();
				AC=Integer.parseInt(aggretedColumn);

				
					//QueryInputParameters qip = Connecting_class.inputParameters(querry);
					try {
						conn = Mysqlconnection.connetion();
						String inserting = "insert into inputparameter (inputquery, noofnestedsubqueries, noofselectionpredictes, noofequalityselectionpredicate, noofnonequalityselectionpredicate,noofjoins,noofequijoinpredicate,noofnonequijoinpredicate,noofsortedcoloumn,noofaggregation)"
								+ "values (?, ?, ?, ?, ?,?,?,?,?,?)";
						PreparedStatement statement = (PreparedStatement) conn.prepareStatement(inserting);
						statement.setString(1, querry);
						statement.setInt(2, NONQ);
						statement.setInt(3, SP);
						statement.setInt(4, equalitySelectionInteger);
						statement.setInt(5, nonequalitySelectionInteger);
						statement.setInt(6, NOJ);
						statement.setInt(7, equijoinsInteger);
						statement.setInt(8, nonequijoininteger);
						statement.setInt(9, SC);
						statement.setInt(10, AC);
						statement.execute();
						conn.close();
						contentPane.add(scrollPane);
						readinput(queryInputParameterModel);
						scrollPane.setViewportView(listQIP);

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			}
		});
		btnRunQuery.setBounds(335, 300, 89, 23);
		contentPane.add(btnRunQuery);

		JButton btnAddItems = new JButton("Add Items");
		btnAddItems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				querry = queryString.getText().toString();
				try {
					String xmlinput = Connecting_class.calculation(querry);
					QueryPlan plan = Connecting_class.queryPlan(xmlinput, Connecting_class.executionTime);
					int[] selectedItem = listQIP.getSelectedIndices();
					int forigenkey = 0;
					for (int i = 0; i < selectedItem.length; i++) {
						forigenkey = queryInputParameterModel.get(selectedItem[i]).getId();
						// System.out.println(queryInputParameterModel.get(selectedItem[i]).getId());
					}
					writeQueryInput(forigenkey, Connecting_class.executionTime, xmlinput, querry);
					writeNodeValues(querry, forigenkey);
				} catch (SQLException | JDOMException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnAddItems.setBounds(531, 300, 89, 23);
		contentPane.add(btnAddItems);
		
		JLabel lblNewLabel_3 = new JLabel("Number of Nested queries");
		lblNewLabel_3.setBounds(388, 72, 100, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SelectionPredictes");
		lblNewLabel_4.setBounds(388, 117, 100, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("number of joins");
		lblNewLabel_5.setBounds(388, 159, 86, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("number of sorted column");
		lblNewLabel_6.setBounds(388, 204, 100, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Aggreated coloumn");
		lblNewLabel_7.setBounds(388, 246, 100, 14);
		contentPane.add(lblNewLabel_7);
		
		numberOfnestedQueries = new JTextField();
		numberOfnestedQueries.setBounds(498, 72, 51, 20);
		contentPane.add(numberOfnestedQueries);
		numberOfnestedQueries.setColumns(10);
		
		selectionPredicates = new JTextField();
		selectionPredicates.setBounds(498, 114, 51, 20);
		contentPane.add(selectionPredicates);
		selectionPredicates.setColumns(10);
		
		numberofjoin = new JTextField();
		numberofjoin.setBounds(498, 156, 55, 20);
		contentPane.add(numberofjoin);
		numberofjoin.setColumns(10);
		
		sortcolomn = new JTextField();
		sortcolomn.setBounds(498, 201, 51, 20);
		contentPane.add(sortcolomn);
		sortcolomn.setColumns(10);
		
		aggretedcoloumn = new JTextField();
		aggretedcoloumn.setBounds(498, 243, 61, 20);
		contentPane.add(aggretedcoloumn);
		aggretedcoloumn.setColumns(10);

	}

	public ArrayList<QueryInputParameters> readinput(DefaultListModel<QueryInputParameters> listmodelQIP)
			throws SQLException {
		ArrayList<QueryInputParameters> arrayListQIP = new ArrayList<>();
		String table_selection = "select* from inputparameter";
		conn = Mysqlconnection.connetion();
		ResultSet resultset;
		java.sql.Statement statement;
		statement = conn.createStatement();
		resultset = statement.executeQuery(table_selection);
		while (resultset.next()) {
			QueryInputParameters QIPobject = new QueryInputParameters(resultset.getInt("id"),
					resultset.getString("inputquery"));
			// System.out.println(QIPobject);
			if (listmodelQIP != null)
				listmodelQIP.addElement(QIPobject);
			arrayListQIP.add(QIPobject);
		}
		conn.close();
		return arrayListQIP;

	}

	public void writeQueryInput(int id, double executionTimevalue, String requiredXML, String quer)
			throws SQLException, JDOMException, IOException {
		QueryPlan QP = Connecting_class.queryPlan(requiredXML, executionTimevalue);
		conn = Mysqlconnection.connetion();
		ArrayList<Node> list = Connecting_class.calculateQueryNodePlan(quer);
		int size = list.size();
		String insertingQueryInput = "insert into queryplan (nonparallelplanreason, cachedplansize, compiletime, cputime,compilememory,serialrequiredmemory,serialdesiredmemory,estimatedavailablitymemorygrant,estimatedpagescached,estimatedavailablitydegreeofparallisim,sizeofnodes,idofinputparameter,executiontime)"
				+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement statement = (PreparedStatement) conn.prepareStatement(insertingQueryInput);
		statement.setString(1, QP.getNonParallelPlanReason());
		statement.setInt(2, QP.getCachedPlanSize());
		statement.setInt(3, QP.getCompileTime());
		statement.setInt(4, QP.getCpuTime());
		statement.setInt(5, QP.getCompileMemory());
		statement.setInt(6, QP.getSerialRequiredMemeory());
		statement.setInt(7, QP.getSerialdesiredMemeory());
		statement.setInt(8, QP.getEstimatedAvailablityMemoryGrant());
		statement.setInt(9, QP.getCachedPlanSize());
		statement.setInt(10, QP.getEstimatedAvailablityDegreeOfParallisim());
		statement.setInt(11, size);
		statement.setInt(12, id);
		statement.setDouble(13, executionTimevalue);
		statement.execute();
		// System.out.println("added values sucessfully" +
		// QP.getEstimatedAvailablityDegreeOfParallisim());
		conn.close();

	}

	public void writeNodeValues(String queryNode, int forgeinKey) throws JDOMException, IOException, SQLException {
		ArrayList<Node> nodeList = Connecting_class.calculateQueryNodePlan(queryNode);
		conn = Mysqlconnection.connetion();
		String insertingNodeInput = "insert into node (physicaloperation,logicaloperation,estimaterow,estimateio,estimatecpu,avgrowsize,estimatedtotalsubtreecost,tablecrdinality,parallel,estimatedrewinds,estimatedrebuilds,estimatedexecutionmode,idqueryinputparameters)"
				+ "values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement statement = (PreparedStatement) conn.prepareStatement(insertingNodeInput);
		for (int i = 0; i < nodeList.size(); i++) {
			statement.setString(1, nodeList.get(i).getPhysicalOperation());
			statement.setString(2, nodeList.get(i).getLogicalOperation());
			statement.setDouble(3, nodeList.get(i).getEstimateRows());
			statement.setDouble(4, nodeList.get(i).getEstimateIO());
			statement.setDouble(5, nodeList.get(i).getEstimateCPU());
			statement.setDouble(6, nodeList.get(i).getAvgRowSize());
			statement.setDouble(7, nodeList.get(i).getEstimatedTotalSubTreeCost());
			statement.setString(8, nodeList.get(i).getTableCardianlity());
			statement.setDouble(9, nodeList.get(i).getParallel());
			statement.setDouble(10, nodeList.get(i).getEstimateRewinds());
			statement.setDouble(11, nodeList.get(i).getEstimateRebuilds());
			statement.setString(12, nodeList.get(i).getEstimatedExecutionMode());
			statement.setInt(13, forgeinKey);
			statement.execute();

		}
		conn.close();
		queryInputParameterModel.clear();
		JOptionPane.showMessageDialog(null, "SUCESSFULLY ADDED ");

	}
}
