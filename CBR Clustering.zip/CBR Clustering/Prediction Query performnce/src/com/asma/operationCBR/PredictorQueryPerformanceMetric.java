package com.asma.operationCBR;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;

import com.asma.CBR.CenteriodPointOfCluster;
import com.asma.CBR.InputAndSelectedFeatures;
import com.asma.CBR.MinimumNumberCalculation;
import com.asma.CBR.SelectedFeature;
import com.asma.Simulation.LasVegas;
import com.asma.Testing.TestClassForSelectedFeatures;
import com.asma.Testing.Testfile;
import com.asma.Testing.randomLasVegas;
import com.asma.thesis.QueryInputParameters;

import weka.classifiers.trees.J48;
import weka.clusterers.ClusterEvaluation;
import weka.clusterers.SimpleKMeans;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class PredictorQueryPerformanceMetric {
	private static BufferedWriter bufferGWriter;
	private static StringBuilder sb = null;
	private static Scanner reader;
	public static int sizeOfOverallDataset;
	private static SimpleKMeans kmeans;
	private static InputAndSelectedFeatures inputAndSelectedFeatures;
	private static QueryInputParameters queryInputParameters;
	private static SelectedFeature selectedFeatures;
	private static ArrayList<InputAndSelectedFeatures> listInputAndSelectedFeature;
	static double precision = 0.0;

	public PredictorQueryPerformanceMetric() {
		// TODO Auto-generated constructor stub
	}

	private static StringBuilder readFromFile() throws IOException {
		StringBuilder sb = new StringBuilder();
		File file = new File("./input/DataSet.csv");
		BufferedReader bufferreader = new BufferedReader(new FileReader(file));
		String line = null;
		while ((line = bufferreader.readLine()) != null) {
			sb.append(line + "\n");
		}

		bufferreader.close();
		return sb;

	}

	public static void main(String... arg) throws Exception {
		// cacheplansize();
		// compilememory();
		// compileTime();
		// estimatedPagesCached();
		// sizeOfNode();
		// executionTime();
//		System.out.println("enter value");
//		reader = new Scanner(System.in);
//		double sys= System.currentTimeMillis();
//		int n = reader.nextInt();
//		Opertion(n);
//		finalCalculation(1, 2, 3, 4, 2, 1, 3, 4, 2, n);
//        double sys1=System.currentTimeMillis();
//        double va=(sys1-sys);
//        System.out.println("Time "+va);
		LasVegas lasvegas= new randomLasVegas();
		lasvegas.randomAlgorithm();
	}

	public static ArrayList<InputAndSelectedFeatures> Opertion(int n) throws Exception {
		listInputAndSelectedFeature = new ArrayList<>();
		// queryInputParameters = new QueryInputParameters();
		// selectedFeatures = new SelectedFeature();
		kmeans = new SimpleKMeans();
		BufferedWriter writer = new BufferedWriter(new FileWriter("output\\K-means-output.csv"));
		kmeans.setPreserveInstancesOrder(true);
		kmeans.setSeed(10);
		kmeans.setPreserveInstancesOrder(true);
		kmeans.setNumClusters(n);
		DataSource dataSource = new DataSource("test\\estimatedpageschache.csv");
		Instances unlabeled = dataSource.getDataSet();
		kmeans.buildClusterer(unlabeled);
		int[] assignments = kmeans.getAssignments();
		ClusterEvaluation eval = new ClusterEvaluation();
		eval.setClusterer(kmeans);
		eval.evaluateClusterer(unlabeled);
		Instances labeled = new Instances(unlabeled);
		unlabeled.setClassIndex(unlabeled.numAttributes() - 1);
		J48 j48 = new J48();
		j48.setUnpruned(true);
		String[] split = null;
		for (int j = 0; j < labeled.numInstances(); j++) {
			String a = labeled.instance(j).toString();
			split = a.split(",");
			
			queryInputParameters = new QueryInputParameters(Integer.valueOf(split[0]), Integer.valueOf(split[1]),
					Integer.valueOf(split[2]), Integer.valueOf(split[3]), Integer.valueOf(split[4]),
					Integer.valueOf(split[5]), Integer.valueOf(split[6]), Integer.valueOf(split[7]),
					Integer.valueOf(split[8]));
			selectedFeatures = new SelectedFeature(Integer.valueOf(split[9]), Integer.valueOf(split[10]),
					Integer.valueOf(split[11]), Integer.valueOf(split[12]), Integer.valueOf(split[13]),
					Integer.valueOf(split[14]), Integer.valueOf(split[15]), split[16]);
			inputAndSelectedFeatures = new InputAndSelectedFeatures(queryInputParameters, selectedFeatures,
					assignments[j]);

			// }
			listInputAndSelectedFeature.add(inputAndSelectedFeatures);

		}

		writer.write(labeled.toString());
		writer.newLine();
		writer.flush();
		return listInputAndSelectedFeature;
	}

	public static HashMap<Integer, ArrayList<InputAndSelectedFeatures>> clusteringObject(int op) throws Exception {

		InputAndSelectedFeatures inputAndSelectedFeatured = null;
		SelectedFeature selectedFeatureed = null;
		QueryInputParameters queryIP = null;
		ArrayList<InputAndSelectedFeatures> listOfInputandSelectedFeatures = null;
		HashMap<Integer, ArrayList<InputAndSelectedFeatures>> mapofInputselectedfeature = new HashMap<>();
		listOfInputandSelectedFeatures = Opertion(op);
		//System.out.println("here achived");
		for (int j = 0; j < op; j++) {
			//listOfInputandSelectedFeatures = new ArrayList<>();
			bufferGWriter = new BufferedWriter(new FileWriter("cluster\\Cluster" + j + ".csv"));
			bufferGWriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
					+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins"
					+ "," + "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
					+ "noofaggregation" + "," + "compilememory" + "," + "cachedplansize" + "," + "estimatedpagescached"
					+ "," + "cputime" + "," + "compiletime" + "," + "sizeofnodes" + "," + "executiontime" + ","
					+ "class" + "," + "cluster" + "\n");
			for (int i = 0; i < listInputAndSelectedFeature.size(); i++) {
				if (listInputAndSelectedFeature.get(i).getCluster() == j) {
					System.out.println("sub queries"+listInputAndSelectedFeature.get(i).getQueryInputParameter()
							.getNumberOfNestedSubQueries());
					bufferGWriter.write(listInputAndSelectedFeature.get(i).getQueryInputParameter()
							.getNumberOfNestedSubQueries()
							+ ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfSelectionPredicates()
							+ ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfequalitySelectionPredicate()
							+ ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfnonequalitySelectionPredicate()
							+ "," + listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfJoins() + ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfEquiJoinsPredicate()
							+ ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfNonEquiJoinPredicate()
							+ ","
							+ listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfSortedColoumn()
							+ "," + listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfAggregation()
							+ "," + listInputAndSelectedFeature.get(i).getSelctedfeature().getCachedPlanSize() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getCompileMemory() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getEstimatedPages() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getCpuTime() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getCompileTime() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getSizeOfNodes() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getExecutionTime() + ","
							+ listInputAndSelectedFeature.get(i).getSelctedfeature().getClasses() + ","
							+ listInputAndSelectedFeature.get(i).getCluster() + "\n");
					queryIP = new QueryInputParameters(
							listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfSelectionPredicates(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfequalitySelectionPredicate(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfnonequalitySelectionPredicate(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfJoins(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter()
									.getNumberOfNonEquiJoinPredicate(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
							listInputAndSelectedFeature.get(i).getQueryInputParameter().getNumberOfAggregation());
					selectedFeatureed = new SelectedFeature(

							listInputAndSelectedFeature.get(i).getSelctedfeature().getCachedPlanSize(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getCompileMemory(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getEstimatedPages(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getCpuTime(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getCompileTime(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getSizeOfNodes(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getExecutionTime(),
							listInputAndSelectedFeature.get(i).getSelctedfeature().getClasses());
					inputAndSelectedFeatured = new InputAndSelectedFeatures(queryIP, selectedFeatureed,
							listInputAndSelectedFeature.get(i).getCluster());
					listOfInputandSelectedFeatures.add(inputAndSelectedFeatured);
				}
				mapofInputselectedfeature.put(j, listOfInputandSelectedFeatures);
			}
			bufferGWriter.flush();
			bufferGWriter.close();

		}
		return mapofInputselectedfeature;

	}

	public static ArrayList<CenteriodPointOfCluster> centeriodPointOfCluster(int op) {
		CenteriodPointOfCluster centerPointOFCluster = null;
		String[] split = null;
		double b = 0.0;
		ArrayList<CenteriodPointOfCluster> listCenteriodPointOfClusters = new ArrayList<>();
		Instances instances = kmeans.getClusterCentroids();
		String arrInstances = null;
		// System.out.println(instances);
		if (op > instances.size())
			return null;
		if (op == 0 && instances.size() == 0)
			return null;

//		15System.out.println("value of instance" + instances.size());
		// JOptionPane.showMessageDialog(null, "error idr ha");
		for (int i = 0; i < op; i++) {
			arrInstances = instances.get(i).toString();
			split = arrInstances.split(",");
			for (int j = 0; j < split.length - 8; j++) {
				b = Double.valueOf(split[j]);
				// System.out.println(b);
				centerPointOFCluster = new CenteriodPointOfCluster(Double.valueOf(split[0]), Double.valueOf(split[1]),
						Double.valueOf(split[2]), Double.valueOf(split[3]), Double.valueOf(split[4]),
						Double.valueOf(split[5]), Double.valueOf(split[6]), Double.valueOf(split[7]),
						Double.valueOf(split[8]));
			}
			if (listCenteriodPointOfClusters != null) {
				listCenteriodPointOfClusters.add(centerPointOFCluster);
			}

		}
		return listCenteriodPointOfClusters;

	}

	public static ArrayList<Double> minimumCal(int numberOfNestedSubQueries, int numberOfSelectionPredicates,
			int numberOfequalitySelectionPredicate, int numberOfnonequalitySelectionPredicate, int numberOfJoins,
			int numberOfEquiJoinsPredicate, int numberOfNonEquiJoinPredicate, int numberOfSortedColoumn,
			int numberOfAggregation, int n) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(new File("Centeriod\\centeriod.csv")));
		DecimalFormat df = new DecimalFormat("####0.00");
		double number = 0.0;
		bw.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + "," + "noofequalityselectionpredicate" + ","
				+ "noofnonequalityselectionpredicate" + "," + "noofjoins" + "," + "noofequijoinpredicate" + ","
				+ "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + "," + "noofaggregation" + "\n");
		ArrayList<Double> listOfEquiDistanceofCenteriodPoints = new ArrayList<>();

		ArrayList<CenteriodPointOfCluster> listofCPC = centeriodPointOfCluster(n);
		if (listofCPC != null)
			for (int i = 0; i < listofCPC.size(); i++) {

				number = square(numberOfNestedSubQueries, listofCPC.get(i).getNumberOfNestedSubQueries())
						+ square(numberOfSelectionPredicates, listofCPC.get(i).getNumberOfSelectionPredicates())
						+ square(numberOfequalitySelectionPredicate,
								listofCPC.get(i).getNumberOfequalitySelectionPredicate())
						+ square(numberOfnonequalitySelectionPredicate,
								listofCPC.get(i).getNumberOfnonequalitySelectionPredicate())
						+ square(numberOfJoins, listofCPC.get(i).getNumberOfJoins())
						+ square(numberOfEquiJoinsPredicate, listofCPC.get(i).getNumberOfEquiJoinsPredicate())
						+ square(numberOfNonEquiJoinPredicate, listofCPC.get(i).getNumberOfNonEquiJoinPredicate())
						+ square(numberOfSortedColoumn, listofCPC.get(i).getNumberOfSortedColoumn())
						+ square(numberOfAggregation, listofCPC.get(i).getNumberOfAggregation());
				// number = Double.valueOf(df.format(number));
				//System.out.println("number without sqrt" + number);
				number = Math.sqrt(number);
				// System.out.println("number with sqrt"+number);
				listOfEquiDistanceofCenteriodPoints.add(number);
				bw.write(listofCPC.get(i).getNumberOfNestedSubQueries() + ","
						+ listofCPC.get(i).getNumberOfSelectionPredicates() + ","
						+ listofCPC.get(i).getNumberOfequalitySelectionPredicate() + ","
						+ listofCPC.get(i).getNumberOfnonequalitySelectionPredicate() + ","
						+ listofCPC.get(i).getNumberOfJoins() + "," + listofCPC.get(i).getNumberOfEquiJoinsPredicate()
						+ "," + listofCPC.get(i).getNumberOfNonEquiJoinPredicate() + ","
						+ listofCPC.get(i).getNumberOfSortedColoumn() + "," + listofCPC.get(i).getNumberOfAggregation()
						+ "\n");

			}
		bw.close();
		return listOfEquiDistanceofCenteriodPoints;

	}

	public static double square(int num1, double num2) {
		double c;
		c = (num1 - num2);
		return c * c;

	}

	public static ArrayList<MinimumNumberCalculation> selectionOfClusterAndOperation(int numberOfNestedSubQueries,
			int numberOfSelectionPredicates, int numberOfequalitySelectionPredicate,
			int numberOfnonequalitySelectionPredicate, int numberOfJoins, int numberOfEquiJoinsPredicate,
			int numberOfNonEquiJoinPredicate, int numberOfSortedColoumn, int numberOfAggregation, int n)
			throws Exception {
		ArrayList<Double> cal = minimumCal(numberOfNestedSubQueries, numberOfSelectionPredicates,
				numberOfequalitySelectionPredicate, numberOfnonequalitySelectionPredicate, numberOfJoins,
				numberOfEquiJoinsPredicate, numberOfNonEquiJoinPredicate, numberOfSortedColoumn, numberOfAggregation,
				n);
		if (cal == null || cal.size() == 0) {
			return null;
		}
		double smallestNumber = cal.get(0);
		int valuePosition = 0;
		double minimumNumber = 0.0;
		ArrayList<MinimumNumberCalculation> listminimumNumberOfCalculation = new ArrayList<>();
		MinimumNumberCalculation minimumNumberCalculation = null;
		SelectedFeature selectedFeatures = null;
		HashMap<Integer, ArrayList<InputAndSelectedFeatures>> mapof = clusteringObject(n);
		ArrayList<InputAndSelectedFeatures> sizeANDinputandSelectedFeatures = null;
		for (int i = 0; i < cal.size(); i++) {
		//	System.out.println(cal.get(i));
			if (smallestNumber > cal.get(i)) {
				smallestNumber = cal.get(i);
				valuePosition = i;
			}
		}

		for (Map.Entry<Integer, ArrayList<InputAndSelectedFeatures>> traversing : mapof.entrySet()) {
			int key = traversing.getKey();
			if (key == valuePosition) {
				sizeANDinputandSelectedFeatures = traversing.getValue();
//				System.out.println("key value " + key);
//				System.out.println("size of array" + sizeANDinputandSelectedFeatures.size());
			}
		}
		for (int i = 0; i < sizeANDinputandSelectedFeatures.size(); i++) {
			minimumNumber = square(numberOfNestedSubQueries,
					sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter().getNumberOfNestedSubQueries())
					+ square(numberOfSelectionPredicates,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter()
									.getNumberOfSelectionPredicates())
					+ square(numberOfequalitySelectionPredicate,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter()
									.getNumberOfequalitySelectionPredicate())
					+ square(numberOfnonequalitySelectionPredicate,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter()
									.getNumberOfnonequalitySelectionPredicate())
					+ square(numberOfJoins,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter().getNumberOfJoins())
					+ square(numberOfEquiJoinsPredicate,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter()
									.getNumberOfEquiJoinsPredicate())
					+ square(numberOfNonEquiJoinPredicate,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter()
									.getNumberOfNonEquiJoinPredicate())
					+ square(numberOfSortedColoumn,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter().getNumberOfSortedColoumn())
					+ square(numberOfAggregation,
							sizeANDinputandSelectedFeatures.get(i).getQueryInputParameter().getNumberOfAggregation());
			selectedFeatures = new SelectedFeature(
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getCompileMemory(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getCachedPlanSize(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getEstimatedPages(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getCpuTime(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getCompileTime(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getSizeOfNodes(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getExecutionTime(),
					sizeANDinputandSelectedFeatures.get(i).getSelctedfeature().getClasses());
			minimumNumber = Math.sqrt(minimumNumber);
			minimumNumberCalculation = new MinimumNumberCalculation(selectedFeatures, minimumNumber);
			listminimumNumberOfCalculation.add(minimumNumberCalculation);
		}
		return listminimumNumberOfCalculation;
	}

	public static TestClassForSelectedFeatures finalCalculation(int a, int b, int c, int d, int e, int f, int g, int h,
			int l, int n) throws Exception {
		TestClassForSelectedFeatures TCFSF = null;
		SelectedFeature SF = null;
		double db = 0;
		ArrayList<MinimumNumberCalculation> listOfMinimumNumberOfCalculation = selectionOfClusterAndOperation(a, b, c,
				d, e, f, g, h, l, n);

		MinimumNumberCalculation MNCclass = null;
		if (listOfMinimumNumberOfCalculation != null) {
			MinimumNumberCalculation MNC = listOfMinimumNumberOfCalculation.get(0);
			for (int i = 0; i < listOfMinimumNumberOfCalculation.size(); i++) {
				if (MNC.getEculdainDistance() > listOfMinimumNumberOfCalculation.get(i).getEculdainDistance()) {
					MNC = listOfMinimumNumberOfCalculation.get(i);
				}
				// System.out.println(
				// i + " " + "list of miniimum " +
				// listOfMinimumNumberOfCalculation.get(i).getEculdainDistance());
			}
			MNCclass = new MinimumNumberCalculation(MNC.getSelectedfeature(), MNC.getEculdainDistance());
//			System.out.println("Eculadian distance" + MNC.getEculdainDistance());
//			System.out.println("Execution Time" + MNC.getSelectedfeature().getExecutionTime());
			db = MNC.getEculdainDistance();
			db = 1 / db;
			db = Math.round(db * 100);
			// System.out.println("selected Features" +
			// MNC.getSelectedfeature().getCachedPlanSize());
			SF = new SelectedFeature(MNC.getSelectedfeature().getCachedPlanSize(),
					MNC.getSelectedfeature().getCompileMemory(), MNC.getSelectedfeature().getCpuTime(),
					MNC.getSelectedfeature().getCompileTime(), MNC.getSelectedfeature().getEstimatedPages(),
					MNC.getSelectedfeature().getSizeOfNodes(), MNC.getSelectedfeature().getExecutionTime(),
					MNC.getSelectedfeature().getClasses());
			TCFSF = new TestClassForSelectedFeatures(SF, db, MNC.getEculdainDistance());

		}
		return TCFSF;
	}

	public static void executionTime() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualShortNumber = 0;
		int actualLongNumber = 0;
		int predicatedShortNumber = 0;
		int predicatedLongNumber = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\executiontime.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 793; i < inputdata.size(); i++) {
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			if (inputdata.get(i).getSelctedfeature().getExecutionTime() > 100) {
				Class = "Long";
				actualLongNumber = actualLongNumber + 1;

			} else {
				Class = "Short";
				actualShortNumber = actualShortNumber + 1;
			}
			if (TCFSF.getSF().getClasses().equals("short"))
				predicatedShortNumber = predicatedShortNumber + 1;
			if (TCFSF.getSF().getClasses().equals("long"))
				predicatedLongNumber = predicatedLongNumber + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("Short") && TCFSF.getSF().getClasses().equals("short")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("Short") && TCFSF.getSF().getClasses().equals("long"))
				falsePositive = falsePositive + 1;
			if (Class.equals("Long") && TCFSF.getSF().getClasses().equals("short"))
				falseNegative = falseNegative + 1;
			if (Class.equals("Long") && TCFSF.getSF().getClasses().equals("long"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicatedLongNumber);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actualLongNumber;
		double actShortnumber = actualShortNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

	public static void cacheplansize() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualzeroNumber = 0;
		int actual1Number = 0;
		int predicatedzeroNumber = 0;
		int predicated1Number = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\cacheplansize.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 793; i < inputdata.size(); i++) {//
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			if (inputdata.get(i).getSelctedfeature().getCachedPlanSize() <= 100) {
				Class = "0";
				actualzeroNumber = actualzeroNumber + 1;

			} else {
				Class = "1";
				actual1Number = actual1Number + 1;
			}
			if (TCFSF.getSF().getClasses().equals("0"))
				predicatedzeroNumber = predicatedzeroNumber + 1;
			if (TCFSF.getSF().getClasses().equals("1"))
				predicated1Number = predicated1Number + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
				falsePositive = falsePositive + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
				falseNegative = falseNegative + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicated1Number);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actual1Number;
		double actShortnumber = actualzeroNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

	public static void compilememory() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualzeroNumber = 0;
		int actual1Number = 0;
		int predicatedzeroNumber = 0;
		int predicated1Number = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\compilememory.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 793; i < inputdata.size(); i++) {
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			if (inputdata.get(i).getSelctedfeature().getCompileMemory() <= 1200) {
				Class = "0";
				actualzeroNumber = actualzeroNumber + 1;

			} else {
				Class = "1";
				actual1Number = actual1Number + 1;
			}
			if (TCFSF.getSF().getClasses().equals("0"))
				predicatedzeroNumber = predicatedzeroNumber + 1;
			if (TCFSF.getSF().getClasses().equals("1"))
				predicated1Number = predicated1Number + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
				falsePositive = falsePositive + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
				falseNegative = falseNegative + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicated1Number);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actual1Number;
		double actShortnumber = actualzeroNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

	public static void compileTime() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualzeroNumber = 0;
		int actual1Number = 0;
		int predicatedzeroNumber = 0;
		int predicated1Number = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\compiletime.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 793; i < inputdata.size(); i++) {
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			if (inputdata.get(i).getSelctedfeature().getCompileTime() <= 75) {
				Class = "0";
				actualzeroNumber = actualzeroNumber + 1;

			} else {
				Class = "1";
				actual1Number = actual1Number + 1;
			}
			if (TCFSF.getSF().getClasses().equals("0"))
				predicatedzeroNumber = predicatedzeroNumber + 1;
			if (TCFSF.getSF().getClasses().equals("1"))
				predicated1Number = predicated1Number + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
				falsePositive = falsePositive + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
				falseNegative = falseNegative + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicated1Number);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actual1Number;
		double actShortnumber = actualzeroNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

	public static void estimatedPagesCached() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualzeroNumber = 0;
		int actual1Number = 0;
		int predicatedzeroNumber = 0;
		int predicated1Number = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\estimatedpagescached.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 126; i < inputdata.size() - 669; i++) {
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			System.out.println("estimated value" + inputdata.get(i).getSelctedfeature().getEstimatedPages());
			if (inputdata.get(i).getSelctedfeature().getEstimatedPages() >= 1280) {
				System.out.println("my");
				Class = "0";
				actualzeroNumber = actualzeroNumber + 1;

			} else {
				Class = "1";
				actual1Number = actual1Number + 1;
			}
			if (TCFSF.getSF().getClasses().equals("0"))
				predicatedzeroNumber = predicatedzeroNumber + 1;
			if (TCFSF.getSF().getClasses().equals("1"))
				predicated1Number = predicated1Number + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
				falsePositive = falsePositive + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
				falseNegative = falseNegative + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicated1Number);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actual1Number;
		double actShortnumber = actualzeroNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

	public static void sizeOfNode() throws Exception {
		int truePositive = 0;
		int trueNegative = 0;
		int falsePositive = 0;
		int falseNegative = 0;
		int actualzeroNumber = 0;
		int actual1Number = 0;
		int predicatedzeroNumber = 0;
		int predicated1Number = 0;
		int total = 0;
		int n = 0;
		BufferedWriter bufferwriter = null;
		StringBuilder sb1 = new StringBuilder();
		reader = new Scanner(System.in);
		bufferwriter = new BufferedWriter(new FileWriter(new File("Result\\SizeOfNode.csv")));
		System.out.println("Enter number of Clusters");
		String Class = null;
		n = reader.nextInt();
		int predication = 0;
		ArrayList<InputAndSelectedFeatures> inputdata = Testfile.resultFile();
		bufferwriter.write("noofnestedsubqueries" + "," + "noofselectionpredictes" + ","
				+ "noofequalityselectionpredicate" + "," + "noofnonequalityselectionpredicate" + "," + "noofjoins" + ","
				+ "noofequijoinpredicate" + "," + "noofnonequijoinpredicate" + "," + "noofsortedcoloumn" + ","
				+ "noofaggregation" + "," + "," + "Actual cachedplansize" + "," + "Actual compilememory" + ","
				+ "Actual cputime" + "," + " Actual compiletime" + "," + " Actual estimated pages cached" + ","
				+ "Actual sizeofnodes" + "," + "Actual executiontime" + "," + " Actual class" + "," + ","
				+ "Predicted cachedplansize" + "," + "Predicted compilememory" + "," + "Predicted cputime" + ","
				+ " Predicted compiletime" + "," + " Predicted estimatedPagescached" + "," + "Predicted sizeofnodes"
				+ "," + "Predicted executiontime" + "," + " Predicted class" + "," + "ED" + "," + "PP" + "," + "p" + ","
				+ "\n");
		// System.out.println(inputdata.size());

		for (int i = 793; i < inputdata.size(); i++) {
			listInputAndSelectedFeature = Opertion(n);
			TestClassForSelectedFeatures TCFSF = finalCalculation(
					inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates(),
					inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfJoins(),
					inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate(),
					inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn(),
					inputdata.get(i).getQueryInputParameter().getNumberOfAggregation(), n);
			// System.out.println("Eculidain
			// Distance"+TCFSF.getEcludianDistance());
			if (inputdata.get(i).getSelctedfeature().getSizeOfNodes() <= 15) {
				Class = "0";
				actualzeroNumber = actualzeroNumber + 1;

			} else {
				Class = "1";
				actual1Number = actual1Number + 1;
			}
			if (TCFSF.getSF().getClasses().equals("0"))
				predicatedzeroNumber = predicatedzeroNumber + 1;
			if (TCFSF.getSF().getClasses().equals("1"))
				predicated1Number = predicated1Number + 1;

			if (TCFSF.getPredicatedPercentage() >= 80.0 || TCFSF.getPredicatedPercentage() == 0.0) {
				predication = 1;
			} else {
				predication = 0;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("0")) {
				truePositive = truePositive + 1;
			}
			if (Class.equals("0") && TCFSF.getSF().getClasses().equals("1"))
				falsePositive = falsePositive + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("0"))
				falseNegative = falseNegative + 1;
			if (Class.equals("1") && TCFSF.getSF().getClasses().equals("1"))
				trueNegative = trueNegative + 1;
			// System.out.println("truePositive "+truePositive);

			sb1.append(inputdata.get(i).getQueryInputParameter().getNumberOfNestedSubQueries() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSelectionPredicates() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfnonequalitySelectionPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfJoins() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfEquiJoinsPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfNonEquiJoinPredicate() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfSortedColoumn() + ","
					+ inputdata.get(i).getQueryInputParameter().getNumberOfAggregation() + "," + ",");
			sb1.append(inputdata.get(i).getSelctedfeature().getCachedPlanSize() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileMemory() + ","
					+ inputdata.get(i).getSelctedfeature().getCpuTime() + ","
					+ inputdata.get(i).getSelctedfeature().getCompileTime() + ","
					+ inputdata.get(i).getSelctedfeature().getEstimatedPages() + ","
					+ inputdata.get(i).getSelctedfeature().getSizeOfNodes() + ","
					+ inputdata.get(i).getSelctedfeature().getExecutionTime() + "," + Class + "," + ",");
			sb1.append(TCFSF.getSF().getCachedPlanSize() + "," + TCFSF.getSF().getCompileMemory() + ","
					+ TCFSF.getSF().getCpuTime() + "," + TCFSF.getSF().getCompileTime() + ","
					+ TCFSF.getSF().getEstimatedPages() + "," + TCFSF.getSF().getSizeOfNodes() + ","
					+ TCFSF.getSF().getExecutionTime() + "," + TCFSF.getSF().getClasses() + ",");
			sb1.append(TCFSF.getEcludianDistance() + "," + TCFSF.getPredicatedPercentage() + ",");
			sb1.append(predication + ",");
			sb1.append("\n");

			// System.out.println(sb1.toString());

		}
		System.out.println("predicted Long number" + predicated1Number);
		bufferwriter.write(sb1.toString() + "\n" + "\n");
		bufferwriter.write("," + "True Positive" + "," + truePositive + "\n");
		bufferwriter.write("," + "False Positive" + "," + falsePositive + "\n");
		bufferwriter.write("," + "False Negative " + "," + falseNegative + "\n");
		bufferwriter.write("," + "True Negative" + "," + trueNegative + "\n");
		total = (truePositive + trueNegative + falsePositive + falseNegative);
		double accuracy = (truePositive + trueNegative);
		accuracy = (accuracy / total);
		double misclassificationRate = (falsePositive + falseNegative);
		misclassificationRate = (misclassificationRate / total);
		double actLongnumber = actual1Number;
		double actShortnumber = actualzeroNumber;
		double v = truePositive + falseNegative;
		double truePositiveRate = (truePositive / v);
		double fpr = (falsePositive + trueNegative);
		double falsePositiveRate = (falsePositive / fpr);
		double specificity = (trueNegative / actShortnumber);
		double val = (truePositive + falsePositive);
		System.out.println("Result" + val);
		precision = truePositive / val;
		double FMeasure = 2 * (precision * truePositiveRate);
		FMeasure = FMeasure / (precision + truePositiveRate);
		System.out.println(truePositive + "result " + precision);
		double prevalence = (actLongnumber / total);
		bufferwriter.write("\n");
		bufferwriter.write("," + "Accuracy" + "," + accuracy + "\n");
		bufferwriter.write("," + "Misclassification Rate " + "," + misclassificationRate + "\n");
		bufferwriter.write("," + "True Positive Rate " + "," + truePositiveRate + "\n");
		bufferwriter.write("," + "false Positive Rate " + "," + falsePositiveRate + "\n");
		bufferwriter.write("," + "specificity " + "," + specificity + "\n");
		bufferwriter.write("," + "precision " + "," + precision + "\n");
		bufferwriter.write("," + "prevalence " + "," + prevalence + "\n");
		bufferwriter.write("," + "fmeasure " + "," + FMeasure + "\n");

		// System.out.println("Result "+accuracy+" "+misclassificationRate+"
		// "+truePositiveRate+" "+falsePositiveRate+" "+specificity+"
		// "+precision+" "+prevalence);

		bufferwriter.close();
		// bufferwriter.flush();

	}

}
